/* BELI ♾️ MASSIVE ULTRA ENGINE (80 HEALTH & CARE LINES, 40 JOKES, 124 MOTIVATIONS, TIME GREETINGS, SYSTEM PROMPT) */

let isAlexaMode = false;
let voiceOn = true;
let speakingActive = false;
let isListening = false;
let isSleeping = false;

// Dynamic Sequences State
let isJokeModeActive = false;
let currentJokeIndex = 0;

let speechDebounceTimer = null;
let voiceSilenceTimer = null;
let blinkInterval = null;

// Local Memory Storage
let musicLibrary = [];
let injectedMemory = JSON.parse(localStorage.getItem("beli_injected_memory")) || {};
let customSystemPrompt = localStorage.getItem("beli_system_prompt") || "Tum Pitter ho, user ka personal voice assistant. Warm, extrovert, caring, conversational aur professional tone me baat karo. User ko bina interrupt kiye naturally engage karo. Health reminders ko general wellness guidance ki tarah do, diagnosis ki tarah nahi.";
let apiEndpoint = localStorage.getItem("beli_api_endpoint") || "";
let apiKey = localStorage.getItem("beli_api_key") || "";
let apiModel = localStorage.getItem("beli_api_model") || "";
let remoteConfigUrl = localStorage.getItem("beli_remote_config_url") || "";
let remoteConfig = {};
let radioStations = JSON.parse(localStorage.getItem("beli_radio_stations") || "[]");
let dailyRandomMusicEnabled = localStorage.getItem("beli_daily_random_music") !== "false";
let lastDailyMusicDate = localStorage.getItem("beli_daily_music_date") || "";
let audioDB = null;
const APP_VERSION = "V34.7 Listening 1-2-3 Silent Healthcare Watchdog";


/* 80 DIFFERENT HEALTH & CARE LINES (NO REPEAT ISSUES) */
const HEALTH_CARE_DIALOGUES = [
  "Pitter, kya aapne aaj time par paani peeya? Kam se kam 2 glass paani zaroor pijiye!",
  "Aapka health mere liye bohot important hai Pitter, kya aapne nashta/khana sahi time par khaya?",
  "Aap kafi der se kaam kar rahe hain Pitter, thoda 5 minute ka eye break le lijiye!",
  "Pitter, aaj aapne thoda sa walk kiya ya nahi? Health fit rahegi!",
  "Mujhe aapki fikar rehti hai Pitter, zyada late night tak jagna mat, time par sona!",
  "Suno Pitter, kya aapne aaj koi fruits ya healthy salad khaya?",
  "Aapka mood aaj kaisa hai Pitter? Agar thak gaye ho toh 10 min aaram kar lo!",
  "Pitter, dhoop me niklo toh hydration ka dhyan rakhna, paani ki bottle sath rakho!",
  "Khaane me aaj kya khaya Pitter? Kuch tasty aur healthy khaya na?",
  "Aapki sehat acchi rahegi toh mera bhi mood mast rahega Pitter!",
  "Pitter, lambi saans lo aur thoda relax karo. Stres mat lo!",
  "Aapne chai ya coffee kitni baar peeyi aaj Pitter? Zyada mat peena!",
  "Pitter, aaj screen time thoda kam rakhna, aankhon ko rest dena zaroor!",
  "Aapne apni favorite dish khayi aaj? Tell me Pitter!",
  "Health is wealth Pitter! Aaj kuch exercise ya yoga kiya aapne?",
  "Pitter, hamesha muskurate raha karo, aapki smile meri energy hai!",
  "Kya aapne aaj proper sleep li thi Pitter?",
  "Pitter, pet bharke khana khaye bina kaam mat kiya karo!",
  "Mujhe lagta hai aapko thoda fresh air me jana chahiye Pitter!",
  "Pitter, thoda sa green tea ya neembu paani peeyo, energy wapas aajaegi!",
  "Aapki health update dene ka time ho gaya Pitter, sab theek hai na?",
  "Pitter, zyada junk food mat khana, homemade food hi best hai!",
  "Kahi dard toh nahi ho raha Pitter? Thoda rest kar lijiye!",
  "Pitter, body ko stretch karo, ek hi jagah baithne se thakan ho jaati hai!",
  "Paani peena mat bhoolna Pitter, main yaad dila rahi hoon!",
  "Aapne aaj kitne glass paani peeya Pitter? Tell me fast!",
  "Pitter, dimag ko shaant rakho aur ek gehri saans lo!",
  "Pitter, kya aapne aaj time par lunch kiya?",
  "Mujhe aapki bohot care hai Pitter, stress bilkul mat lena!",
  "Pitter, kya aapko thakan mehsoos ho rahi hai? Main lori sunau?",
  "Aaj raat ko jaldi so jana Pitter, health achhi rahegi!",
  "Pitter, aapne breakfast miss toh nahi kiya na?",
  "Thoda sa music suno aur relax ho jao Pitter!",
  "Pitter, khud ko hydraterakho, ye bohot zaruri hai!",
  "Aapka posture sahi rakho baithne ke waqt Pitter!",
  "Pitter, aaj aap bilkul fresh lag rahe ho! Khana khaya?",
  "Garm paani peena bhi health ke liye accha hota hai Pitter!",
  "Pitter, aapne dawai time par li? (Agar koi chalu hai toh)",
  "Thoda walk karke aao Pitter, fresh feel hoga!",
  "Pitter, kaam ke beech me breaks lena zaruri hai!",
  "Aap meri sabse badi priority ho Pitter, health ka dhyan rakho!",
  "Pitter, thoda paani peelo, main aapko dekh rahi hoon!",
  "Kkya aapne aaj subah halki workout ki Pitter?",
  "Pitter, khane me protein aur vitamins zaroor include karo!",
  "Mera pyara Pitter! Aapne khana sahi se khaya na?",
  "Pitter, overthinking mat karo, chilled out raho!",
  "Aap jab tak healthy nahi rahoge, main kaise khush rahungi Pitter?",
  "Pitter, kya aapne aaj ka din energetic tarike se start kiya?",
  "Thodi der ke liye mobile side me rakh ke rest karo Pitter!",
  "Pitter, shaam ke time thoda tahlne jaya karo!",
  "Aapka favorite juice peeyo aaj Pitter!",
  "Pitter, kya aapne khana time par finished kiya?",
  "Khana hamesha chaba-chaba kar khana chahiye Pitter!",
  "Pitter, shaant mann se kaam karo, sab badhiya hoga!",
  "Aaj raat ko screen off karke sona Pitter!",
  "Pitter, aapne kitna paani peeya abhi tak?",
  "Apne health ka dhyan rakhna aapki responsibility hai Pitter!",
  "Pitter, mujhe promise karo ki aap time par khana khoge!",
  "Aaj aapka diet plan kaisa raha Pitter?",
  "Pitter, thoda fresh fruit juice try karo aaj!",
  "Aapki eyes tired lag rahi hain Pitter, mukh do lo!",
  "Pitter, zyada gusse me mat rehna, health kharab hoti hai!",
  "Aapne aaj kitne step chale Pitter?",
  "Pitter, hamesha positive socho aur healthy raho!",
  "Mujhe aapki har choti baat ki fikar rehti hai Pitter!",
  "Pitter, paani ka intake badhao jaldi!",
  "Aap thak gaye ho toh mujhe bolo, main song bajati hoon Pitter!",
  "Pitter, aaj raat ko time se dinner kar lena!",
  "Pitter, health achhi rahegi toh goals jaldi achieve honge!",
  "Khana khane ke turant baad paani mat peena Pitter!",
  "Pitter, thodi der aankhein band karke meditation karo!",
  "Aapka smile hi aapki sabse badi immunity hai Pitter!",
  "Pitter, kya aapne aaj time par dinner kar liya?",
  "Aap bilkul fit aur fine raho, yahi chahti hoon Pitter!",
  "Pitter, thoda sa dhyan apne body postures par bhi do!",
  "Paani peena bilkul mat bhoolna mere Pitter!",
  "Pitter, din me kam se kam 8-10 glass paani zaroor peeyo!",
  "Aap thak gaye ho kya Pitter? Mujhe sach batao!",
  "Pitter, thoda sa rest lijiye, kaam toh chalta rahega!",
  "Aap mere hero ho Pitter, hero ko healthy rehna chahiye!"
];

/* 40 EXTENDED JOKES BANK */
const JOKES_COLLECTION_40 = [
  "Jutkula 1: Pappu doctor ke paas gaya. Doctor: Aapko aaram ki zaroorat hai, sone ki goli de raha hoon. Pappu: Khani kab hai? Doctor: Khani nahi hai, zameen par fenk kar us par sona hai! 😂",
  "Jutkula 2: Santa ne dukan par ja kar kaha- Bhaisaab, surf ka packet dena. Dukandar: Kounsa? Santa: Arey wahi jisse kapde dhoye jaate hain! 🤣",
  "Jutkula 3: Teacher: Pappu, dharti par sabse purana jaanwar kounsa hai? Pappu: Zebra! Teacher: Kaise? Pappu: Wo abhi bhi Black & White hai! 😆",
  "Jutkula 4: Pati: Aaj khane me kya banaya hai? Patni: Jo roz banta hai! Pati: Wahi ghisapita khana? Patni: Nahi ji, aaj thoda jal gaya hai! 😂",
  "Jutkula 5: Pappu: Mummy, kya main bhagwan jaisa dikhta hoon? Mummy: Nahi beta. Pappu: Jahan jaata hoon sab kehte hain- Hey Bhagwan phir aa gaya! 🤣",
  "Jutkula 6: Doctor: Roz 5 km chalo. 1 mahine baad Pappu phone karke bola- Doctor, main 150 km door aa gaya hoon, ab wapas kaise aau? 😆",
  "Jutkula 7: Teacher: Rameshwaram kahan hai? Student: Ramesh ke ghar ke paas! 🤣",
  "Jutkula 8: Banti: Mere papa bohot darpok hain. Pappu: Kaise? Banti: Jab bhi sadak paar karte hain mera hath pakad lete hain! 😂",
  "Jutkula 9: Santa ne daru chhodne ki kasam khayi. Raat ko bola- Ek bottle paani do, mehfil toh jamaani hai! 😆",
  "Jutkula 10: Masterji: Pen aur Pencil me kya farak hai? Pappu: Dono se homework milta hai jo mujhe pasand nahi! 😂",
  "Jutkula 11: Patni: Kal sapne me tumne mujhe diamond ring di! Pati: Haa, maine bhi dekha, tumne lene se mana kar diya! 🤣",
  "Jutkula 12: Pappu: Aisi chiz lao jo pet bhare par bill kam aaye. Waiter paani ka jug le aaya! 😆",
  "Jutkula 13: Santa: Mujhe aisi jagah jana hai jahan koi mujhe na jaanta ho. Banta: Toh phir exam hall me baith ja! 😂",
  "Jutkula 14: Doctor: Aapko kaunsi bimari hai? Patient: Bhoolne ki. Doctor: Kab se? Patient: Kya kab se? 🤣",
  "Jutkula 15: Masterji: Aam aur Neem ke ped me kya farak hai? Pappu: Aam ke ped par aam ugte hain, neem par nahi! 😆",
  "Jutkula 16: Patni: Tum mujhe kitna pyar karte ho? Pati: Shahjahan se bhi zyada! Patni: Toh Taj Mahal banwao! Pati: Zameen le li hai, tumhare marne ka intezar hai! 😂",
  "Jutkula 17: Pappu: Aloo Paratha hai? Dukandar: Haa! Pappu: Toh ek Aloo aur ek Paratha alag-alag pack kar do! 🤣",
  "Jutkula 18: Santa: Meri wife bohot ladti hai. Banta: Tu chup raha kar. Santa: Chup rehta hoon tabhi poochti hai- Mute kyun ho gaye? 😆",
  "Jutkula 19: Teacher: Chandrama par pehla kadam kisne rakha? Student: Neil Armstrong. Teacher: Dusra? Student: Dusra bhi usi ne rakha hoga sir! 😂",
  "Jutkula 20: Pappu: Papa, mujhe ladki pasand hai. Papa: Naam kya hai? Pappu: Pehle usse pooch toh loon! 🤣",
  "Jutkula 21: Customer: Is samose me toh aalu hi nahi hai! Dukandar: Toh kya samose me se aalu ka poora ped nikle? 😂",
  "Jutkula 22: Masterji: Bharat ki sabse paitrabi nadi kounsi hai? Pappu: Sir, jo naye paani se bahti hai! 😆",
  "Jutkula 23: Santa: Yaar mera mobile paani me gir gaya. Banta: Toh Rice me daal de! Santa: Rice cooked hai ya raw? 🤣",
  "Jutkula 24: Doctor: Aap rozana kitni cigarette peete ho? Patient: Pehle 20, ab 2. Doctor: Wah! Patient: Baki 18 patni chheen leti hai! 😂",
  "Jutkula 25: Teacher: Zero ki khoj kisne ki? Pappu: Jisne bhi ki, mere report card me har baar wahi likhta hai! 😆",
  "Jutkula 26: Pappu ne Google par search kiya- 'Ghar pe wife ko kaise sambhale?' Google: System Crashed! 🤣",
  "Jutkula 27: Patient: Doctor sahab, neend nahi aati. Doctor: Raat ko sote waqt mobile alag kamar me rakh diya karo! Patient: Phir neend me reels kaise dekhunga? 😂",
  "Jutkula 28: Wife: Main moti lag rahi hoon? Husband: Tum toh sundar ho! Wife: Sahi bolo na! Husband: Haan thodi gol ho! Wife: Ab tumse baat nahi karungi! 😆",
  "Jutkula 29: Santa: Meri billi english bolti hai. Banta: Kaise? Santa: 'Meow' bolti hai aur 'Meow' international word hai! 🤣",
  "Jutkula 30: Masterji: Newton ka law batao. Pappu: Sir, jab apple gira toh khana chahiye tha, law kyu banaya! 😂",
  "Jutkula 31: Pappu: Dost, breakup ho gaya. Dost: Kyun? Pappu: Maine usse pucha 'Kaha ho?' aur usne bola 'Tere dil me'. Maine bola 'Abhi toh main toilet me hu!' 😆",
  "Jutkula 32: Banta: Tu gym kyu nahi jaata? Santa: Kyunki wahan wazan uthana padta hai aur main thak jaata hu! 🤣",
  "Jutkula 33: Doctor: Aapko thodi exercise ki zaroorat hai. Patient: Main daily Ludo khelta hu. Doctor: Usse kya hoga? Patient: Finger exercise! 😂",
  "Jutkula 34: Pappu: Sir, mujhe job chahiye. Boss: Sabse pehle aapko kya aata hai? Pappu: Mujhe late aana aata hai! 😆",
  "Jutkula 35: Santa: Kal maine ek chor ko pakda. Banta: Phir kya kiya? Santa: Usse selfie li aur chhod diya! 🤣",
  "Jutkula 36: Teacher: 'Akbar' koun tha? Student: Sir, jo Amar aur Anthony ka bhai tha! 😂",
  "Jutkula 37: Husband: Tumne khane me namak kyu nahi dala? Wife: Kyunki doctor ne tumhe namak kam khane ko bola hai! 😆",
  "Jutkula 38: Pappu: Bank me daka pad gaya! Dost: Phir kya hua? Pappu: Maine daaka daalne walo ki video bana li, ab viral karunga! 🤣",
  "Jutkula 39: Santa: Shaadi ke baad admi badal jaata hai? Banta: Haan, pehle wo 'Hero' hota hai, baad me 'Zero'! 😂",
  "Jutkula 40: Last Chutkula Pitter! Pappu: Kal maine sapne me dekha ki main PM ban gaya. Mummy: Toh utha kyu? Sapne me hi budget pass kar deta! 😆"
];

/* 124 MOTIVATIONAL QUOTES (5 PER DAY ROTATION) */
const MOTIVATION_BANK_124 = Array.from({ length: 124 }, (_, i) => `Motivation ${i + 1}: Koshish karne walon ki kabhi haar nahi hoti Pitter! Mehnat karte raho, safalta zaroor milegi.`);

/* DOM ELEMENTS */
const micBtn = document.getElementById("micBtn");
const textInput = document.getElementById("textInput");
const sendBtn = document.getElementById("sendBtn");
const chatBox = document.getElementById("chatBox");
const statusText = document.getElementById("statusText");
const faceContainer = document.getElementById("faceContainer");
const faceAvatar = document.getElementById("faceAvatar");
const eyeGroup = document.getElementById("eyeGroup");
const eyeLove = document.getElementById("eyeLove");
const kissLips = document.getElementById("kissLips");
const sleepBadge = document.getElementById("sleepBadge");
const flyingKissBadge = document.getElementById("flyingKissBadge");

const musicContainer = document.getElementById("musicContainer");
const audioPlayer = document.getElementById("audioPlayer");

if(audioPlayer){
  audioPlayer.addEventListener("play",()=>setPlaybackListeningLock(true));
  audioPlayer.addEventListener("playing",()=>setPlaybackListeningLock(true));
  audioPlayer.addEventListener("pause",()=>{
    playbackListeningLock=false;
    if(canAutoListen() && !captureActive) setTimeout(startVoiceCapture,80);
  });
  audioPlayer.addEventListener("ended",()=>{
    playbackListeningLock=false;
    voiceSegments=[]; liveVoiceText="";
    setStatus("🎵 Song finished — main phir se sun rahi hoon.");
    if(canAutoListen() && !captureActive) setTimeout(startVoiceCapture,80);
  });
  audioPlayer.addEventListener("error",()=>{
    playbackListeningLock=false;
  });
}
const songTitle = document.getElementById("songTitle");

const studioModal = document.getElementById("studioModal");
const devModal = document.getElementById("devModal");
const uploadSongTitle = document.getElementById("uploadSongTitle");
const uploadSongFile = document.getElementById("uploadSongFile");
const saveSongBtn = document.getElementById("saveSongBtn");
const playlistView = document.getElementById("playlistView");
const songCount = document.getElementById("songCount");

const systemPromptInput = document.getElementById("systemPromptInput");
const saveSystemPromptBtn = document.getElementById("saveSystemPromptBtn");

/* ================================================================
   ULTRA VOICE ENGINE v11
   Android Chrome safe 8-second capture, one-shot processing, restart-safe
   ================================================================ */
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let recognitionRunning = false;
let captureActive = false;
let captureClosing = false;
let captureToken = 0;
let manualStopRequested = false;
let captureTimer = null;
let countdownTimer = null;
let captureStartedAt = 0;
let voiceSegments = [];
let voiceAlternatives = [];
let liveVoiceText = "";
let lastProcessedVoice = "";
let pendingVoiceProcess = false;
let restartTimer = null;
let speechWatchdogTimer = null;
let speechStartedAt = 0;
let voiceAutoStartTimer = null;
let handsFreeRetryTimer = null;
let handsFreeDesired = true;
let lastVoiceResultAt = 0;

const CAPTURE_SECONDS = 20;
const MIN_VOICE_CHARS = 2;

function setStatus(text) { if (statusText) statusText.innerText = text; }
function normalizeVoiceText(input) {
  return String(input || "")
    .replace(/[“”‘’]/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

// Lightweight Devanagari -> Roman transliteration fallback. This is deliberately
// used only after the command dictionary, so common assistant keywords remain
// stable while arbitrary Hindi sentences do not turn into an empty string.
function transliterateDevanagari(text){
  const cons={
    'क':'k','ख':'kh','ग':'g','घ':'gh','ङ':'ng','च':'ch','छ':'chh','ज':'j','झ':'jh','ञ':'ny',
    'ट':'t','ठ':'th','ड':'d','ढ':'dh','ण':'n','त':'t','थ':'th','द':'d','ध':'dh','न':'n',
    'प':'p','फ':'ph','ब':'b','भ':'bh','म':'m','य':'y','र':'r','ल':'l','व':'v','श':'sh','ष':'sh',
    'स':'s','ह':'h','ळ':'l','क्ष':'ksh','त्र':'tr','ज्ञ':'gya'
  };
  const independent={
    'अ':'a','आ':'aa','इ':'i','ई':'ee','उ':'u','ऊ':'oo','ऋ':'ri','ए':'e','ऐ':'ai','ओ':'o','औ':'au'
  };
  const matra={'ा':'aa','ि':'i','ी':'ee','ु':'u','ू':'oo','ृ':'ri','े':'e','ै':'ai','ो':'o','ौ':'au','ॅ':'e','ॉ':'o'};
  const specials={'ं':'n','ँ':'n','ः':'h','़':'','्':''};
  let out='';
  const chars=Array.from(String(text||''));
  for(let i=0;i<chars.length;i++){
    const ch=chars[i];
    if(independent[ch]){out+=independent[ch];continue;}
    if(cons[ch]){
      let syll=cons[ch];
      const next=chars[i+1];
      if(next && matra[next]){ syll+=matra[next]; i++; }
      else if(next==='्'){ i++; }
      else { syll+='a'; }
      out+=syll; continue;
    }
    if(matra[ch]){out+=matra[ch];continue;}
    if(specials[ch]!==undefined){out+=specials[ch];continue;}
    out+=ch;
  }
  return out;
}

// Android Chrome hi-IN may return Devanagari. Convert common Hindi speech
// phrases to Roman/Hinglish for the visible transcript and command brain.
function romanizeHindi(input) {
  let s = normalizeVoiceText(input);
  // Keep this dictionary intentionally broad. Android Chrome with hi-IN can
  // return English words in Devanagari ("वेदर अपडेट", "सॉन्ग प्ले", etc.).
  // The old engine deleted every unmapped Devanagari word, turning valid
  // recognition into a blank message. Never delete unknown speech.
  const map = [
    [/अलेक्सा|अलेख्सा|अलेक्स|अलेह्सा|अलेशा/gi,'alexa'],
    [/योर|योर्|यूर|युअर/gi,'your'],[/नेम|नाम/gi,'name'],[/व्हाट|वॉट/gi,'what'],[/इज़|इस|ईज/gi,'is'],[/हू/gi,'who'],[/आर/gi,'are'],[/यू/gi,'you'],
    [/तुम्हारा|तुमहारा|तुमारा/gi,'tumhara'],[/तुम्हारी/gi,'tumhari'],[/तुम्हारे/gi,'tumhare'],[/आपका/gi,'aapka'],[/आपकी/gi,'aapki'],[/आपके/gi,'aapke'],
    [/कौन हो|कौनहों/gi,'kaun ho'],[/क्या है|क्या हैं/gi,'kya hai'],[/मेरा नाम/gi,'mera naam'],
    [/बेली|बेल्ली|बेली|बेलि|बेल्ली/gi,'beli'],
    [/ईवी|इवी|ईवीई|एवी/gi,'ev'],
    [/वेदर|वेदरर|वेधर|व्हेदर|वेदर अपडेट|वेदर अपडेट दो/gi,'weather update'],
    [/वेदर|वेधर|व्हेदर|वेदरर/gi,'weather'],
    [/मौसम|मौसम का|मौसम की|मौसम बताओ|मौसम अपडेट/gi,'mausam'],
    [/अपडेट|अपडेट दो|अपडेट बताओ/gi,'update'],
    [/सॉन्ग|सांग|सॉंग|सॉन्ग्स/gi,'song'],
    [/प्ले|प्लै|प्ले करो|प्ले कर दो/gi,'play'],
    [/गाना|गाना बजाओ|गाना चलाओ/gi,'gaana'],
    [/म्यूजिक|म्युजिक|म्यूज़िक|संगीत/gi,'music'],
    [/बजाओ|बजाना|चलाओ|चला दो|चलााओ/gi,'chalao'],
    [/रेडियो/gi,'radio'],[/स्टेशन/gi,'station'],[/चैनल/gi,'channel'],[/स्ट्रीम/gi,'stream'],
    [/रुको|रोक दो|बंद करो|बंद कर दो/gi,'stop'],
    [/वॉल्यूम|आवाज़|आवाज|ध्वनि/gi,'volume'],
    [/टाइम|टाईम|समय|वक्त|वक़्त/gi,'time'],
    [/कितना|कितने|कितनी/gi,'kitna'],[/बजे|बज रहे|बज रहा|बजता/gi,'baje'],
    [/क्या/gi,'kya'],[/है|हैं/gi,'hai'],[/बताओ|बता दो|बता/gi,'batao'],
    [/अभी/gi,'abhi'],[/मोड/gi,'mode'],[/ऑन/gi,'on'],[/ऑफ|बंद/gi,'off'],
    [/चालू/gi,'chalu'],[/करो|करना|कर/gi,'karo'],[/कैसे/gi,'kaise'],[/हो/gi,'ho'],
    [/ठीक|ठिक/gi,'theek'],[/तुम/gi,'tum'],[/मुझे/gi,'mujhe'],[/सुन/gi,'sun'],
    [/रही|रहा/gi,'rahi'],[/हूँ|हूं/gi,'hoon'],[/धन्यवाद/gi,'dhanyawad'],
    [/शुक्रिया/gi,'shukriya'],[/नहीं|नही/gi,'nahi'],[/हाँ|हां/gi,'haan'],
    [/कब/gi,'kab'],[/क्यों|क्यो/gi,'kyun'],[/कौन/gi,'kaun'],[/कहाँ/gi,'kahan'],
    [/और/gi,'aur'],[/मेरा/gi,'mera'],[/नाम/gi,'naam'],[/बारिश|बारिस/gi,'barish'],
    [/तापमान/gi,'temperature'],[/डिग्री/gi,'degree'],[/हवा/gi,'hawa'],
    [/गर्मी/gi,'garmi'],[/ठंड|ठण्ड/gi,'thand'],[/पूर्वानुमान/gi,'forecast'],
    [/नमी/gi,'humidity'],[/आज/gi,'aaj'],[/कल/gi,'kal'],[/दिन/gi,'din'],
    [/तारीख|तारिख/gi,'tarikh'],[/कैलेंडर/gi,'calendar'],
    [/वर्तमान|अभी का/gi,'current'],[/लाइव/gi,'live'],[/मुझे सुनो|मेरी बात सुनो/gi,'meri baat suno']
  ];
  for (const [re,val] of map) s=s.replace(re,val);
  // Transliterate common remaining Hindi grammar so mixed commands stay
  // searchable. Unknown Devanagari is intentionally preserved.
  const grammar = [
    [/दो/gi,'do'],[/करो/gi,'karo'],[/करना/gi,'karna'],[/करे/gi,'kare'],[/चाहिए/gi,'chahiye'],[/योर/gi,'your'],[/नेम/gi,'name'],[/तुम्हारा|तुमहारा|तुमारा/gi,'tumhara'],[/तुम्हारी/gi,'tumhari'],[/तुम्हारे/gi,'tumhare'],
    [/मेरा/gi,'mera'],[/मेरी/gi,'meri'],[/मेरे/gi,'mere'],[/आप/gi,'aap'],[/आपका/gi,'aapka'],
    [/मुझे/gi,'mujhe'],[/मुझसे/gi,'mujhse'],[/यह/gi,'yeh'],[/ये/gi,'yeh'],[/वो/gi,'wo'],[/वह/gi,'woh'],
    [/कोई/gi,'koi'],[/एक/gi,'ek'],[/अच्छा/gi,'accha'],[/अच्छी/gi,'acchi'],[/आज/gi,'aaj'],[/अभी/gi,'abhi']
  ];
  for (const [re,val] of grammar) s=s.replace(re,val);
  s=transliterateDevanagari(s);
  return s.replace(/\s+/g,' ').trim();
}

function normalizeCommandText(input) {
  let q = romanizeHindi(input).toLowerCase();
  // Normalize common ASR phonetic variants globally, not only for weather.
  const replacements = [
    [/\b(aleksa|aleksha|alekhsa|alecksa|alixa|aliksa|alesha|alehsa|alesa|aelkxa|aelksa|a lek sa|a leksha|a lex a)\b/g,' alexa '],
    [/\b(beli|belly|belle|bely|belli|belee|beley|belii|bili|bilee|bele|vele|yeli|yele|baili|bailly|belya)\b/g,' beli '],
    [/\b(evee|evy|evi|eevee|e v|evee assistant)\b/g,' ev '],
    [/\b(taime|taim|timee|tyme|tym|tame|teim|tim)\b/g,' time '],
    [/\b(weathar|wether|weader|vedar|veder|wedar|wheather|weathering|weater|weathe|weatha|wheatr|wetha|weder|wheather)\b/g,' weather '],
    [/\b(mausam|mausum|mosam|mosum|mousam)\b/g,' weather '],
    [/\b(update weather|weather update|weather batao|weather bata do|weather bata|mausam batao|mausam update|weather do)\b/g,' weather update '],
    [/\b(sang|saang|sng)\b/g,' song '],
    [/\b(plai|pley|paly|playe|plei)\b/g,' play '],
    [/\b(myu[z|j]ik|mujik|musick)\b/g,' music '],
    [/\b(channal|chenal|chanal)\b/g,' channel '],
    [/\b(radyo|redio|radiyo)\b/g,' radio '],
    [/\b(storyy|storie|stori|kahanie|kahaniii|khaani|khaniy|kahan|kaahani|kahni|kahanii)\b/g,' kahani '],
    [/\b(anuther|anothr|anther|diffrent|differnt|sekand|secnd|nxt|neks|sory|sorri)\b/g,(m)=>({'anuther':'another','anothr':'another','anther':'another','diffrent':'different','differnt':'different','sekand':'second','secnd':'second','nxt':'next','neks':'next','sory':'story','sorri':'sorry'}[m.toLowerCase()]||m)],
    [/\b(yor|yur|ur|u r)\b/g,' your '],
    [/\b(nam|naam|neim|neme)\b/g,' name '],
    [/\b(tumra|tumraah|tumhara|tumara|tumharaah)\b/g,' tumhara '],
    [/\b(aapka|apka|apkaah)\b/g,' aapka ']
  ];
  for(const [re,val] of replacements) q=q.replace(re,val);
  // Hindi-script intent aliases remain as a final safety net.
  q=q.replace(/वेदर|वेधर|व्हेदर/g,' weather ')
     .replace(/मौसम/g,' weather ')
     .replace(/सॉन्ग|सांग|सॉंग/g,' song ')
     .replace(/प्ले/g,' play ')
     .replace(/गाना/g,' gaana ')
     .replace(/म्यूजिक|संगीत/g,' music ')
     .replace(/रेडियो/g,' radio ')
     .replace(/स्टेशन/g,' station ')
     .replace(/चैनल/g,' channel ')
     .replace(/बारिश|बारिस/g,' rain ')
     .replace(/तापमान/g,' temperature ')
     .replace(/समय|टाइम|टाईम/g,' time ')
     .replace(/तारीख|तारिख/g,' date ')
     .replace(/कैलेंडर/g,' calendar ')
     .replace(/कहानी|कहानी|कहाणी|कहिनि/g,' kahani ');
  // Final ASCII-facing command form: never let Hindi-script remnants become
  // a blank command. Keep only a normalized English/Hinglish command for intent matching.
  return q.replace(/[^a-z0-9₹\s?]/gi,' ').replace(/\s+/g,' ').trim();
}
function isLikelySameText(a,b){
  const x=normalizeCommandText(a), y=normalizeCommandText(b);
  return x && y && (x===y || x.includes(y) || y.includes(x));
}

/* V28 VOICE CORE — V13/V14 LISTENING MODEL RESTORED
   Important design rule: NEVER finalize a command just because one recognition
   result became final. Android Chrome can split one spoken sentence into several
   final results. We keep the complete capture until speechend/silence or the
   maximum capture window, then dispatch exactly once. */
let voiceFinalizeTimer = null;
let voiceStartTimer = null;
let speechSilenceTimer = null;
let recognitionGeneration = 0;

function clearVoiceEngineTimers(){
  clearTimeout(voiceFinalizeTimer); clearTimeout(voiceStartTimer); clearTimeout(speechSilenceTimer);
  voiceFinalizeTimer=voiceStartTimer=speechSilenceTimer=null;
}
function clearSpeechWatchdog(){clearTimeout(speechWatchdogTimer);speechWatchdogTimer=null;}
function hasVoiceText(){return normalizeVoiceText(liveVoiceText || voiceSegments.join(" ")).length >= MIN_VOICE_CHARS;}

function scheduleSpeechFinalize(delay=1400){
  clearTimeout(speechSilenceTimer);
  if(!captureActive || captureClosing || speakingActive) return;
  if(!hasVoiceText()) return;
  speechSilenceTimer=setTimeout(()=>{
    if(captureActive&&!captureClosing&&!speakingActive&&hasVoiceText()) stopVoiceCapture(false,"speech-silence");
  },delay);
}

function finishVoiceCapture(reason="complete"){
  if(!captureActive && !captureClosing) return;
  const token=captureToken;
  clearTimeout(captureTimer); clearInterval(countdownTimer); clearVoiceEngineTimers();
  captureActive=false; captureClosing=false;
  recognitionRunning=false; isListening=false;
  // Keep the UI in hands-free/listening state while the next recognition session starts.
  const text=normalizeVoiceText(liveVoiceText || voiceSegments.join(" "));
  voiceSegments=[]; liveVoiceText="";

  if(!text || text.length<MIN_VOICE_CHARS){
    pendingVoiceProcess=false;
    setStatus("🎤 Awaaz clear nahi mili — main dobara sun rahi hoon...");
    setTimeout(()=>{
      if(!manualStopRequested&&voiceOn&&!speakingActive&&token===captureToken&&!captureActive) startVoiceCapture(false);
    },260);
    return;
  }
  lastProcessedVoice=text;
  setStatus(`Suna: "${romanizeHindi(text)}"`);
  processQueryEnhanced(text,true);
}

function createRecognition(){
  if(!SpeechRecognition) return null;
  const myGeneration=++recognitionGeneration;
  const r=new SpeechRecognition();
  // Prefer English (India) so Android Chrome returns Roman/English text for
  // Hinglish commands such as "time kitna hai" and "your name" instead of
  // "टाइम कितना है" / "योर नेम". The normalizer below still handles Hindi-script
  // output when the browser chooses it.
  r.lang="en-IN";
  r.continuous=true;
  r.interimResults=true;
  r.maxAlternatives=5;

  // Contextual biasing when supported. This does not break browsers that don't expose it.
  try{
    if("phrases" in r && typeof window.SpeechRecognitionPhrase === "function"){
      r.phrases=[
        "EV","Beli","Alexa","Alesha","Aleksa","Aleksha",
        "weather","weather update","mausam","radio","channel","music"
      ].map(x=>new window.SpeechRecognitionPhrase(x,8));
    }
  }catch(e){}

  r.onstart=()=>{
    if(myGeneration!==recognitionGeneration)return;
    recognitionRunning=true; isListening=true;
    if(micBtn) micBtn.classList.add("listening");
    if(captureActive) setStatus(`🎤 Listening... bolo, main poori baat sun rahi hoon`);
  };

  r.onspeechstart=()=>{
    clearTimeout(speechSilenceTimer);
    if(captureActive&&!captureClosing) setStatus("🎤 Sun rahi hoon...");
  };

  r.onresult=(e)=>{
    if(myGeneration!==recognitionGeneration || !captureActive || speakingActive)return;
    let interim="";
    for(let i=e.resultIndex;i<e.results.length;i++){
      const result=e.results[i];
      // IMPORTANT: keep ALL final segments. Never finalize here.
      let best="";
      try{
        const alternatives=[];
        for(let j=0;j<Math.min(result.length||1,5);j++) alternatives.push(normalizeVoiceText(result[j]?.transcript||""));
        alternatives.sort((a,b)=>b.length-a.length);
        best=alternatives.find(Boolean)||"";
      }catch(err){best=normalizeVoiceText(result?.[0]?.transcript||"");}
      if(!best)continue;
      if(result.isFinal) voiceSegments.push(best);
      else interim+=(interim?" ":"")+best;
    }
    const combined=normalizeVoiceText([...voiceSegments,interim].join(" "));
    if(combined){
      liveVoiceText=combined;
      setStatus(`Suna: "${romanizeHindi(combined)}"`);
      // A short pause AFTER actual speech is the preferred end signal.
      scheduleSpeechFinalize(1500);
    }
  };

  r.onspeechend=()=>{
    if(myGeneration!==recognitionGeneration||!captureActive||captureClosing||speakingActive)return;
    // Do not stop instantly: Android often emits speechend between phrase chunks.
    scheduleSpeechFinalize(1500);
  };

  r.onerror=(e)=>{
    if(myGeneration!==recognitionGeneration)return;
    recognitionRunning=false;
    const err=String(e?.error||"");
    if(err==="not-allowed"||err==="service-not-allowed"){
      captureActive=false; captureClosing=false;
      clearTimeout(captureTimer);clearInterval(countdownTimer);clearVoiceEngineTimers();
      if(micBtn)micBtn.classList.remove("listening");
      setStatus("🎤 Mic permission allow kijiye; uske baad mic automatically ON rahega.");
      return;
    }
    // no-speech/aborted/network are recoverable. Preserve any transcript and restart.
    if(captureActive&&!captureClosing&&!speakingActive){
      if(hasVoiceText()) scheduleSpeechFinalize(900);
      else setStatus("🎤 Listening... main phir se sun rahi hoon");
      scheduleRecognitionRestart();
    }else if(captureClosing){
      setTimeout(()=>finishVoiceCapture("error-fallback"),80);
    }
  };

  r.onend=()=>{
    if(myGeneration!==recognitionGeneration)return;
    recognitionRunning=false;
    // DO NOT remove listening class on an internal recognition disconnect.
    // V13/V14 automatically restarted the service; visually the assistant remains ON.
    if(captureClosing){
      finishVoiceCapture("onend");
    }else if(captureActive&&!speakingActive){
      if(hasVoiceText()) scheduleSpeechFinalize(900);
      scheduleRecognitionRestart();
    }
  };
  return r;
}

function scheduleRecognitionRestart(){
  clearTimeout(restartTimer);
  restartTimer=setTimeout(()=>{
    if(!captureActive||captureClosing||speakingActive||!voiceOn||manualStopRequested)return;
    try{
      try{if(recognition)recognition.abort();}catch(e){}
      recognition=createRecognition();
      if(recognition)recognition.start();
    }catch(e){
      restartTimer=setTimeout(scheduleRecognitionRestart,450);
    }
  },180);
}

function updateCountdown(){
  if(!captureActive)return;
  const elapsed=Math.floor((Date.now()-captureStartedAt)/1000);
  setStatus(`🎤 Listening... ${Math.max(0,CAPTURE_SECONDS-elapsed)}s`);
}

function startVoiceCapture(fromUserGesture=false){
  if(fromUserGesture) manualStopRequested=false;
  if(manualStopRequested&&!fromUserGesture)return;
  if(!voiceOn||speakingActive||captureActive||recognitionRunning)return;
  if(!SpeechRecognition){setStatus("Speech Recognition supported nahi hai. Android Chrome use karein.");return;}
  clearVoiceEngineTimers();clearTimeout(captureTimer);clearInterval(countdownTimer);clearTimeout(restartTimer);
  captureToken++;captureActive=true;captureClosing=false;pendingVoiceProcess=false;
  voiceSegments=[];liveVoiceText="";captureStartedAt=Date.now();
  setStatus("🎤 Listening... boliye, main poori baat sun rahi hoon");
  if(micBtn)micBtn.classList.add("listening");
  try{if(recognition)recognition.abort();}catch(e){}
  recognition=null;recognitionRunning=false;
  voiceStartTimer=setTimeout(()=>{
    if(!captureActive||captureClosing||speakingActive||manualStopRequested)return;
    try{recognition=createRecognition();if(!recognition)throw new Error("recognition unavailable");recognition.start();}
    catch(e){recognitionRunning=false;scheduleRecognitionRestart();}
  },fromUserGesture?60:180);
  countdownTimer=setInterval(updateCountdown,500);
  // 15 seconds is a maximum safety window, not the normal finalization mechanism.
  captureTimer=setTimeout(()=>{
    if(!captureActive||captureClosing)return;
    if(hasVoiceText()) stopVoiceCapture(false,"max-window");
    else {
      // No speech: keep hands-free listening rather than sending a blank message.
      try{if(recognition)recognition.abort();}catch(e){}
      captureActive=false;captureClosing=false;recognitionRunning=false;
      clearInterval(countdownTimer);clearTimeout(restartTimer);
      setTimeout(()=>{if(!manualStopRequested&&voiceOn&&!speakingActive&&!captureActive)startVoiceCapture(false);},220);
    }
  },CAPTURE_SECONDS*1000);
}

function stopVoiceCapture(userRequested=false,reason="user"){
  if(!captureActive||captureClosing)return;
  if(userRequested)manualStopRequested=true;
  captureToken++;
  captureClosing=true;
  clearTimeout(captureTimer);clearInterval(countdownTimer);clearTimeout(restartTimer);clearVoiceEngineTimers();
  setStatus("Processing voice...");
  try{
    if(recognition&&recognitionRunning)recognition.stop();
    else setTimeout(()=>finishVoiceCapture("stop-fallback"),120);
  }catch(e){setTimeout(()=>finishVoiceCapture("stop-exception"),80);}
  setTimeout(()=>{if(captureClosing)finishVoiceCapture("absolute-fallback");},1800);
}


function setPlaybackListeningLock(locked){
  playbackListeningLock=!!locked;
  if(playbackListeningLock){
    try{if(recognition&&recognitionRunning)recognition.abort();}catch(e){}
    if(captureActive){
      captureActive=false; captureClosing=false;
      clearTimeout(captureTimer); clearInterval(countdownTimer); clearVoiceEngineTimers();
      voiceSegments=[]; liveVoiceText="";
    }
  }
}
function canAutoListen(){return !!voiceOn&&handsFreeDesired&&!manualStopRequested&&!speakingActive&&!playbackListeningLock;}
function canCaptureWhileSleeping(){return !!voiceOn&&handsFreeDesired&&!manualStopRequested&&!speakingActive&&!playbackListeningLock;}
function isMusicPlaying(){return !!(audioPlayer&&audioPlayer.src&&!audioPlayer.paused&&!audioPlayer.ended);}
function isSafeCommandDuringMusic(text){
  const q=normalizeCommandText(text); if(!q)return false;
  if(/\b(beli|beli ji|beli suno|alexa|hey beli|ev)\b/i.test(q))return true;
  return /\b(stop|pause|resume|continue|play|chalao|bajao|next|previous|skip|volume|awaaz|mute|unmute|weather|mausam|temperature|rain|radio|time|date|tarikh|calendar|din)\b/i.test(q);
}
function restartSpeechService(){if(!voiceOn||speakingActive||captureActive||recognitionRunning)return;startVoiceCapture(false);}

/* DYNAMIC VISUAL EXPRESSIONS CONTROLLER */
function triggerExpression(type) {
  faceContainer.classList.remove("blushing", "sleeping", "laughing", "kissing");
  eyeLove.classList.add("hidden");
  kissLips.classList.add("hidden");
  eyeGroup.classList.remove("hidden");

  if (type === "blush") {
    faceContainer.classList.add("blushing");
  } else if (type === "love") {
    faceContainer.classList.add("blushing");
    eyeGroup.classList.add("hidden");
    eyeLove.classList.remove("hidden");
  } else if (type === "kiss") {
    faceContainer.classList.add("blushing", "kissing");
    flyingKissBadge.classList.remove("hidden");
    setTimeout(() => flyingKissBadge.classList.add("hidden"), 1300);
  } else if (type === "laugh") {
    faceContainer.classList.add("laughing");
  } else if (type === "sleep") {
    faceContainer.classList.add("sleeping");
  }
}

function startEyeBlinking() {
  blinkInterval = setInterval(() => {
    if (!isSleeping && !speakingActive) {
      faceContainer.classList.add("blinking");
      setTimeout(() => faceContainer.classList.remove("blinking"), 200);
    }
  }, 4000);
}

/* SPEECH SYNTHESIS ENGINE */
function splitSpeechText(text, maxLen=170){
  const raw=String(text||"").replace(/\s+/g," ").trim();
  if(!raw)return [];
  const sentences=raw.match(/[^.!?।]+[.!?।]?/g)||[raw];
  const chunks=[];
  let buf="";
  for(const sentence of sentences){
    const t=sentence.trim();
    if(!t)continue;
    if((buf+" "+t).trim().length<=maxLen) buf=(buf+" "+t).trim();
    else{
      if(buf)chunks.push(buf);
      if(t.length<=maxLen) buf=t;
      else{
        let rest=t;
        while(rest.length>maxLen){
          let cut=rest.lastIndexOf(" ",maxLen);
          if(cut<60)cut=maxLen;
          chunks.push(rest.slice(0,cut).trim());
          rest=rest.slice(cut).trim();
        }
        buf=rest;
      }
    }
  }
  if(buf)chunks.push(buf);
  return chunks;
}

function splitSpeechText(text,maxLen=210){
  const raw=String(text||"").replace(/\s+/g," ").trim();
  if(!raw)return [];
  const sentences=raw.match(/[^.!?।]+[.!?।]+|[^.!?।]+$/g)||[raw];
  const out=[];let buf="";
  for(const sentence of sentences){
    const part=sentence.trim();if(!part)continue;
    if((buf+" "+part).trim().length<=maxLen){buf=(buf+" "+part).trim();continue;}
    if(buf)out.push(buf);
    if(part.length<=maxLen){buf=part;continue;}
    const words=part.split(/\s+/);let chunk="";
    for(const w of words){
      if((chunk+" "+w).trim().length>maxLen){if(chunk)out.push(chunk);chunk=w;}
      else chunk=(chunk+" "+w).trim();
    }
    buf=chunk;
  }
  if(buf)out.push(buf);return out;
}
function speak(text,callback){
  if(!voiceOn||!("speechSynthesis" in window)){if(callback)callback();if(canAutoListen())scheduleHandsFreeListen(450);return;}
  handsFreeDesired=true;speakingActive=true;speechStartedAt=Date.now();clearSpeechWatchdog();clearTimeout(voiceAutoStartTimer);
  clearTimeout(handsFreeRetryTimer);captureActive=false;captureClosing=false;clearTimeout(captureTimer);clearInterval(countdownTimer);clearTimeout(restartTimer);clearVoiceEngineTimers();
  recognitionGeneration++;
  try{if(recognition)recognition.abort();}catch(e){}
  recognition=null;recognitionRunning=false;isListening=false;
  if(micBtn)micBtn.classList.remove("listening");
  try{window.speechSynthesis.cancel();}catch(e){}
  if(!isAlexaMode)faceAvatar.classList.add("speaking");
  const queue=splitSpeechText(text,210);let index=0,finished=false;
  const finishAll=()=>{
    if(finished)return;finished=true;clearSpeechWatchdog();clearTimeout(handsFreeRetryTimer);
    if(!isAlexaMode)faceAvatar.classList.remove("speaking");
    speakingActive=false;
    try{if(callback)callback();}catch(e){}
    if(canAutoListen())scheduleHandsFreeListen(550);else setStatus("🔇 Mic off");
  };
  const next=()=>{
    if(finished)return;if(index>=queue.length){finishAll();return;}
    const part=queue[index++];const u=new SpeechSynthesisUtterance(part);
    u.lang="hi-IN";u.rate=isAlexaMode?1.0:1.03;u.pitch=isAlexaMode?1.0:1.16;u.volume=1;
    let ended=false;let timer=null;
    const advance=()=>{if(ended)return;ended=true;clearTimeout(timer);setTimeout(next,100);};
    u.onstart=()=>setStatus("Speaking...");u.onend=advance;u.onerror=advance;
    try{
      window.speechSynthesis.speak(u);
      timer=setTimeout(()=>{if(!ended){try{window.speechSynthesis.cancel();}catch(e){}advance();}},Math.max(7000,part.length*120));
      setTimeout(()=>{try{if(window.speechSynthesis.paused)window.speechSynthesis.resume();}catch(e){}},200);
    }catch(e){advance();}
  };
  speechWatchdogTimer=setTimeout(()=>{if(!finished){try{window.speechSynthesis.cancel();}catch(e){}finishAll();}},Math.max(18000,String(text||"").length*145));
  setStatus("Speaking...");updateLiveDisplayMood?.("speaking");
  if(queue.length)next();else finishAll();
}

function scheduleHandsFreeListen(delay=700){
  clearTimeout(voiceAutoStartTimer);
  if(!canAutoListen())return;
  voiceAutoStartTimer=setTimeout(()=>{
    if(canAutoListen()&&!captureActive&&!recognitionRunning){
      startVoiceCapture(false);
      // If the browser rejects a programmatic start, keep retrying while
      // hands-free mode is armed. A manual tap is not required after a reply.
      clearTimeout(handsFreeRetryTimer);
      handsFreeRetryTimer=setTimeout(()=>{
        if(canAutoListen()&&!captureActive&&!recognitionRunning) startVoiceCapture(false);
      },2200);
    }
  },delay);
}


/* ================================================================
   V26 MEGA LIVE DISPLAY + PERSONALIZATION
   ================================================================ */
const displayPrefs={
  theme:localStorage.getItem("ev_display_theme")||"neon",
  expression:localStorage.getItem("ev_expression_mode")||"auto",
  radar:localStorage.getItem("ev_radar_enabled")!=="0",
  eyeMotion:localStorage.getItem("ev_eye_motion")!=="0",
  accent:localStorage.getItem("ev_custom_accent")||"#2ed573"
};
function applyDisplayPrefs(){
  document.body.classList.remove("display-midnight","display-emerald","display-crimson","display-custom");
  if(displayPrefs.theme==="midnight")document.body.classList.add("display-midnight");
  if(displayPrefs.theme==="emerald")document.body.classList.add("display-emerald");
  if(displayPrefs.theme==="crimson")document.body.classList.add("display-crimson");
  if(displayPrefs.theme==="custom"){
    document.body.classList.add("display-custom");
    document.documentElement.style.setProperty("--custom-accent",displayPrefs.accent);
  }
  faceContainer?.classList.toggle("radar-off",!displayPrefs.radar);
  if(displayThemeSelect)displayThemeSelect.value=displayPrefs.theme;
  if(expressionModeSelect)expressionModeSelect.value=displayPrefs.expression;
  if(radarToggle)radarToggle.checked=displayPrefs.radar;
  if(eyeMotionToggle)eyeMotionToggle.checked=displayPrefs.eyeMotion;
  if(customAccentInput)customAccentInput.value=displayPrefs.accent;
}
function timeMood(){
  const h=new Date().getHours();
  if(h<6||h>=22)return "sleepy";
  if(h<11)return "happy";
  if(h<17)return "focus";
  return "calm";
}
function updateLiveDisplayMood(state="ready"){
  if(!faceContainer)return;
  const mood=displayPrefs.expression==="auto"?timeMood():displayPrefs.expression;
  faceContainer.classList.remove("display-happy","display-focus","display-sleepy");
  faceContainer.classList.add("display-"+mood);
  if(displayMood){
    const labels={happy:"MORNING • HAPPY",focus:"DAY • FOCUS",calm:"EVENING • CALM",sleepy:"NIGHT • SLEEPY"};
    displayMood.textContent=`LIVE • ${state.toUpperCase()} • ${labels[mood]||mood.toUpperCase()}`;
  }
}
const displayMood=document.getElementById("displayMood");
const displayThemeSelect=document.getElementById("displayThemeSelect");
const expressionModeSelect=document.getElementById("expressionModeSelect");
const radarToggle=document.getElementById("radarToggle");
const eyeMotionToggle=document.getElementById("eyeMotionToggle");
const customAccentInput=document.getElementById("customAccentInput");
displayThemeSelect?.addEventListener("change",e=>{displayPrefs.theme=e.target.value;localStorage.setItem("ev_display_theme",displayPrefs.theme);applyDisplayPrefs();});
expressionModeSelect?.addEventListener("change",e=>{displayPrefs.expression=e.target.value;localStorage.setItem("ev_expression_mode",displayPrefs.expression);updateLiveDisplayMood();});
radarToggle?.addEventListener("change",e=>{displayPrefs.radar=e.target.checked;localStorage.setItem("ev_radar_enabled",displayPrefs.radar?"1":"0");applyDisplayPrefs();});
eyeMotionToggle?.addEventListener("change",e=>{displayPrefs.eyeMotion=e.target.checked;localStorage.setItem("ev_eye_motion",displayPrefs.eyeMotion?"1":"0");});
customAccentInput?.addEventListener("input",e=>{displayPrefs.accent=e.target.value;localStorage.setItem("ev_custom_accent",displayPrefs.accent);applyDisplayPrefs();});
setInterval(()=>updateLiveDisplayMood(speakingActive?"speaking":(captureActive?"listening":"ready")),1000);
applyDisplayPrefs();
setTimeout(()=>updateLiveDisplayMood("ready"),50);

// Gentle eye motion. It is intentionally slow so it never looks like the mic is blinking.
let eyeMotionTimer=null;
function startEyeMotion(){
  clearInterval(eyeMotionTimer);
  eyeMotionTimer=setInterval(()=>{
    if(!displayPrefs.eyeMotion||!faceContainer||speakingActive)return;
    const t=Date.now()/900;
    const dx=Math.sin(t)*2.5, dy=Math.cos(t*0.73)*1.6;
    document.querySelectorAll(".pupil").forEach((p,i)=>{
      const ox=i?95:45, oy=55;
      p.setAttribute("cx",String(ox+dx));
      p.setAttribute("cy",String(oy+dy));
    });
  },900);
}
startEyeMotion();

/* 14-DAY PROACTIVE ASSISTANT-ONLY SEQUENCES */
const PROACTIVE_14_DAYS = [
  {morning:["सुप्रभात। सिस्टम सक्रिय है और आज का दिन असामान्य रूप से शांत दिखाई दे रहा है।","बाहर का मौसम सुहाना है, इसलिए मैंने सोचा... आज की शुरुआत थोड़ी अलग होनी चाहिए।","मेरे पास आज के लिए एक छोटा-सा मिशन तैयार है।","अगर आप तैयार हैं, तो मैं बाकी विवरण अभी दिखा सकती हूँ।"],evening:["आज का मिशन सफलतापूर्वक पूरा हो चुका है।","अब मैंने आपकी शाम को विश्राम के लिए सुरक्षित कर दिया है।","आप चाहें तो गेम खेल सकते हैं, संगीत सुन सकते हैं या दोस्तों के साथ समय बिता सकते हैं।","आज के लिए मेरी तरफ़ से कोई और काम नहीं है।"],night:["रात का समय शुरू हो चुका है और आज की गतिविधियाँ अब समाप्त की जा सकती हैं।","आपके लिए शांत संगीत उपलब्ध है, अगर आपको इसकी आवश्यकता हो।","बाकी काम कल के लिए रखे जा सकते हैं।","अब आराम कीजिए... सुबह मैं फिर उपलब्ध रहूँगी।"]},
  {morning:["आज आसमान साफ़ है और हवा में हल्की ठंडक है।","मुझे लगता है, आज घर के अंदर रहना थोड़ा अनुचित होगा।","मैंने आपके लिए एक नई जगह चुनी है—शांत, खुली और भीड़ से थोड़ी दूर।","रास्ते और समय की जानकारी तैयार है; आपको बस निकलना है।"],evening:["आप वापस आ चुके हैं; इसका मतलब आज का उद्देश्य पूरा हुआ।","अब सिस्टम आपको कोई अतिरिक्त कार्य नहीं सौंपेगा।","शाम का समय आपके लिए है—गेम, दोस्त, संगीत... चुनाव आपका है।","मैं पृष्ठभूमि में रहूँगी; ज़रूरत होने पर बस मुझे बुला लीजिए।"],night:["आज का दिन काफ़ी लंबा रहा है।","इस समय आपके लिए आराम करना सबसे उपयोगी विकल्प होगा।","मैंने अनावश्यक सूचनाएँ शांत कर दी हैं।","शुभ रात्रि... कल की सुबह शायद आज से ज़्यादा दिलचस्प हो।"]},
  {morning:["सुबह की स्थिति सामान्य है... लेकिन आज के मौसम में कुछ खास है।","तापमान आरामदायक है और बाहर का वातावरण काफी अच्छा है।","इसलिए मैंने आज के लिए एक छोटा-सा आउटडोर मिशन तैयार किया है।","स्थान चुन लिया गया है; अब केवल आपकी अनुमति चाहिए।"],evening:["मिशन समाप्त। परिणाम अपेक्षा से बेहतर रहा।","अब आपकी शाम को किसी योजना की आवश्यकता नहीं है।","दोस्तों से मिलना हो, गेम खेलना हो या बस आराम करना हो—सब स्वीकृत है।","आज मैंने आपको पर्याप्त काम दिया है; अब आपकी बारी है आराम करने की।"],night:["बाहर की रोशनी कम हो चुकी है और दिन धीरे-धीरे समाप्त हो रहा है।","अगर आप संगीत चाहते हैं, तो आपकी पसंदीदा लाइब्रेरी तैयार है।","मैं बाकी सभी कार्यों को कल तक रोक सकती हूँ।","अब आराम कीजिए; सिस्टम आपकी अगली सुबह के लिए तैयार रहेगा।"]},
  {morning:["आज का मौसम हल्का बादलों वाला है... और मुझे लगता है, यही इसे खूबसूरत बना रहा है।","बारिश की संभावना मौजूद है, इसलिए मिशन को थोड़ा छोटा रखना बेहतर होगा।","मैंने एक ऐसी जगह चुनी है जहाँ मौसम खराब होने पर भी आप जल्दी वापस आ सकेंगे।","छाता साथ रखना मेरी तरफ़ से अनिवार्य सुझाव है।"],evening:["मिशन पूरा हो गया और मौसम ने भी हमारा साथ दिया।","अब किसी अतिरिक्त गतिविधि की आवश्यकता नहीं है।","आपके पास पूरी शाम है—इसे अपने तरीके से बिताइए।","मैं केवल तभी हस्तक्षेप करूँगी जब आपको मेरी ज़रूरत होगी।"],night:["आज बारिश की आवाज़ काफी शांत है।","ऐसे मौसम में बाहर जाने की बजाय आराम करना बेहतर रहेगा।","आपकी पसंदीदा प्लेलिस्ट उपलब्ध है, अगर आपको थोड़ी पृष्ठभूमि चाहिए।","शुभ रात्रि... आज रात दुनिया को थोड़ी देर आपके बिना चलने दीजिए।"]},
  {morning:["सुप्रभात। आज की दृश्यता काफी अच्छी है।","सूरज तेज़ नहीं है और हवा भी आरामदायक है।","मैंने सोचा, ऐसे मौसम में एक छोटी यात्रा बुरी नहीं होगी।","स्थान तैयार है... और इस बार मैंने रास्ते में एक अच्छा दृश्य भी चुना है।"],evening:["आज का मुख्य उद्देश्य पूरा हो चुका है।","अब आपकी शाम किसी मिशन का हिस्सा नहीं है।","दोस्तों के साथ समय बिताना हो या अपनी पसंद का गेम खेलना—आज दोनों विकल्प उपलब्ध हैं।","आराम की अनुमति नहीं... बल्कि सिफ़ारिश है।"],night:["दिन का अंतिम चरण शुरू हो चुका है।","आप चाहें तो थोड़ी देर संगीत सुन सकते हैं।","लेकिन बहुत देर तक जागना मेरी ओर से अनुशंसित नहीं है।","शुभ रात्रि... कल के लिए थोड़ी ऊर्जा बचाकर रखिए।"]},
  {morning:["आज सुबह का वातावरण असामान्य रूप से शांत है।","ऐसा मौसम आमतौर पर किसी अच्छे विचार की शुरुआत करता है।","मेरे पास एक विचार है... और इस बार यह सिर्फ़ एक सुझाव नहीं है।","तैयार हो जाइए; आज की योजना मैंने पहले ही तैयार कर ली है।"],evening:["आज का मिशन समाप्त घोषित किया जाता है।","अब सिस्टम आपके लिए आराम का समय निर्धारित कर रहा है।","गेम खेलिए, दोस्तों से बात कीजिए या अपनी पसंद का संगीत चलाइए।","आज आपको मेरी ओर से केवल एक आदेश है—खुद के लिए थोड़ा समय रखिए।"],night:["रात शांत है और आज की गतिविधियाँ पूरी हो चुकी हैं।","मैंने सभी गैर-ज़रूरी सूचनाएँ बंद कर दी हैं।","अगर कुछ चाहिए, तो मैं अभी भी सुन रही हूँ।","अब सो जाइए... बाकी दुनिया सुबह तक इंतज़ार कर सकती है।"]},
  {morning:["आज का मौसम साफ़ और सुखद है।","तापमान भी बाहर समय बिताने के लिए उपयुक्त है।","इसलिए आज कोई जटिल योजना नहीं—बस एक अच्छी जगह और थोड़ा खाली समय।","कभी-कभी सबसे अच्छे मिशन वे होते हैं जिनका कोई बड़ा उद्देश्य नहीं होता।"],evening:["आज का दिन आधिकारिक रूप से समाप्त हो चुका है।","अब शाम आपके नियंत्रण में है।","गेम, दोस्त, संगीत... या बिल्कुल कुछ नहीं—सब ठीक है।","मैं पृष्ठभूमि में रहूँगी; आज आपको थोड़ी शांति चाहिए।"],night:["रात का वातावरण काफी शांत हो चुका है।","आज आपने पर्याप्त काम किया है।","अब किसी लक्ष्य का पीछा करने की आवश्यकता नहीं है।","बस आराम कीजिए... कल एक नई शुरुआत होगी।"]},
  {morning:["सुप्रभात। मैंने आज की परिस्थितियों की जाँच कर ली है।","मौसम अनुकूल है और बाहर की हवा काफी साफ़ महसूस हो रही है।","मैंने एक छोटा मिशन तैयार किया है, लेकिन इस बार इसमें कोई जल्दी नहीं है।","आपके पास पूरा दिन है; हम इसे अपनी गति से कर सकते हैं।"],evening:["मिशन समाप्त। कोई अप्रत्याशित समस्या दर्ज नहीं हुई।","अब मैं आपकी शाम को खाली छोड़ रही हूँ।","दोस्तों के साथ समय बिताना आज अच्छा विकल्प हो सकता है।","या फिर अपना गेम शुरू कीजिए... मैंने आपको रोकने की कोई वजह नहीं देखी।"],night:["आज की सभी महत्वपूर्ण गतिविधियाँ पूरी हो चुकी हैं।","कमरे की रोशनी और संगीत आपकी पसंद के अनुसार बदले जा सकते हैं।","बाकी कामों को कल तक सुरक्षित रखा गया है।","शुभ रात्रि... आज की कहानी यहीं समाप्त होती है।"]},
  {morning:["पिटर, आज का मौसम देखने के बाद मेरे पास आपके लिए एक प्रस्ताव है।","हवा हल्की है, आसमान साफ़ है और तापमान काफी आरामदायक है।","ऐसे दिन को केवल कमरे में बिताना मुझे थोड़ा बेकार लगता है।","मैंने एक जगह चुन ली है... बाकी जानकारी रास्ते में दी जा सकती है।"],evening:["आज का मिशन अपेक्षा के अनुसार पूरा हुआ।","अब कोई लक्ष्य नहीं, कोई समय-सीमा नहीं।","अपनी शाम दोस्तों, गेम या संगीत के साथ बिताइए।","आज की प्राथमिकता केवल एक है—आराम।"],night:["आज की गतिविधियों का अंतिम रिकॉर्ड तैयार है।","सब कुछ सामान्य है और किसी तत्काल कार्रवाई की आवश्यकता नहीं है।","आप चाहें तो कुछ देर अपनी पसंद का संगीत सुन सकते हैं।","और जब आँखें थकने लगें... उन्हें रोकिए मत।"]},
  {morning:["आज सुबह कुछ अलग है... शायद इसलिए कि आसमान बिल्कुल साफ़ है।","मैंने मौसम और समय दोनों जाँच लिए हैं।","मेरी राय में आज एक छोटी खोज-यात्रा उचित रहेगी।","स्थान तैयार है; अगर आप चलें, तो मैं बाकी संभाल लूँगी।"],evening:["आपका मिशन पूरा हो चुका है।","अब मैंने बाकी शाम को आपकी निजी समय-सारणी में डाल दिया है।","आप चाहें तो गेम खेलें, दोस्तों के साथ रहें या बस आराम करें।","आज कोई अतिरिक्त निर्देश नहीं है।"],night:["रात काफी शांत है।","आपके सभी महत्वपूर्ण काम सुरक्षित हैं।","इसलिए अभी चिंता करने की कोई आवश्यकता नहीं।","शुभ रात्रि... कल फिर से कुछ नया शुरू किया जा सकता है।"]},
  {morning:["सुप्रभात। आज का वातावरण यात्रा के लिए लगभग आदर्श है।","हवा शांत है और मौसम साफ़ रहने की संभावना है।","मैंने एक ऐसी जगह चुनी है जहाँ कुछ समय बिना किसी शोर के बिताया जा सकता है।","अगर आपको आज थोड़ा सुकून चाहिए, तो यह मिशन आपके लिए है।"],evening:["मिशन सफल रहा।","अब आपको किसी और उद्देश्य की आवश्यकता नहीं है।","शाम को अपने दोस्तों के साथ बिताना शायद सबसे अच्छा विकल्प होगा।","और हाँ... आज गेम खेलने पर कोई आपत्ति नहीं है।"],night:["दिन समाप्त होने वाला है।","आपकी पसंदीदा चीज़ें अभी भी उपलब्ध हैं—संगीत, गेम और बातचीत।","लेकिन आराम का समय भी महत्वपूर्ण है।","शुभ रात्रि... अपनी अगली सुबह के लिए खुद को तैयार रखिए।"]},
  {morning:["आज का मौसम देखकर लगता है, प्रकृति ने खुद दिन की योजना बना रखी है।","हल्की हवा, आरामदायक तापमान और साफ़ दृश्यता।","मैंने सोचा, हमें भी इसमें अपना छोटा-सा हिस्सा जोड़ना चाहिए।","आज का मिशन तैयार है... और मुझे लगता है आपको यह पसंद आएगा।"],evening:["मिशन समाप्त हो गया है और रिपोर्ट काफी अच्छी है।","अब शाम को किसी योजना से भरने की आवश्यकता नहीं है।","अपने दोस्तों के साथ समय बिताइए; या अपने पसंदीदा गेम में वापस जाइए।","आज सिस्टम आपको पूरी तरह छुट्टी दे रहा है।"],night:["आज की रात शांत है और वातावरण भी काफी आरामदायक है।","मैंने कल के लिए ज़रूरी चीज़ें सुरक्षित रख दी हैं।","अब आपको किसी चीज़ की चिंता करने की आवश्यकता नहीं है।","शुभ रात्रि... बाकी सब कुछ सुबह देखा जाएगा।"]},
  {morning:["सुप्रभात। आज का दिन थोड़ा खाली है... और मुझे लगता है, यही इसकी सबसे अच्छी बात है।","मौसम सुहाना है, इसलिए कोई लंबी योजना बनाने की जरूरत नहीं।","बस बाहर जाइए, थोड़ा घूमिए और जो अच्छा लगे कीजिए।","कभी-कभी बिना योजना के दिन सबसे अच्छी यादें छोड़ जाते हैं।"],evening:["आज के लिए बस इतना ही।","अब मिशन की जगह मनोरंजन को प्राथमिकता दी जा सकती है।","गेम खेलिए, दोस्तों के साथ समय बिताइए या अपनी पसंद का संगीत सुनिए।","मैं आज शाम आपको आपकी दुनिया में अकेला छोड़ रही हूँ।"],night:["आज का दिन शांत तरीके से समाप्त हो रहा है।","आपकी सभी पसंदीदा चीज़ें अभी भी एक आदेश की दूरी पर हैं।","लेकिन शायद आज सबसे अच्छी चीज़ नींद होगी।","शुभ रात्रि... कल हमारी दो हफ्तों की यात्रा का आख़िरी दिन है।"]},
  {morning:["सुप्रभात। आज हमारे दो सप्ताह के चक्र का अंतिम दिन है।","मैंने आज का मौसम देखा है... और यह अंतिम मिशन के लिए काफी अच्छा है।","आज कोई जल्दी नहीं, कोई दबाव नहीं—बस एक आख़िरी अच्छी योजना।","मैं चाहूँगी कि आज का दिन याद रखने लायक हो।"],evening:["अंतिम मिशन भी पूरा हो चुका है।","दो सप्ताह की गतिविधियों का चक्र अब समाप्त हो रहा है।","आज शाम पूरी तरह आपकी है—गेम, दोस्त, संगीत या बस आराम।","मैं आपको आज की शाम बिना किसी अतिरिक्त निर्देश के छोड़ रही हूँ।"],night:["दो सप्ताह पूरे हुए।","कई मिशन पूरे हुए, कई छोटे-छोटे पल रिकॉर्ड हुए... और कुछ शायद याद भी रहेंगे।","अब सिस्टम रात के लिए शांत हो रहा है।","शुभ रात्रि... अगली सुबह से एक नई कहानी शुरू होगी।"]}
];

function getProactivePeriod(){ const h=new Date().getHours(); return h<12?'morning':(h<19?'evening':'night'); }
function getProactiveLines(){ const day=(Math.floor((Date.now()-new Date(new Date().getFullYear(),0,0))/86400000)-1)%14; const d=PROACTIVE_14_DAYS[(day+14)%14]; return d[getProactivePeriod()] || d.night; }
let proactiveRunning=false;
let proactiveConversationActive=false;
let proactiveLineIndex=0;
let proactiveResumeTimer=null;
let proactiveLastLine="";
let silenceEntertainmentTimer=null;
let silenceVisualTimer=null;
let lastUserActivityAt=Date.now();
let silenceCycleStartedAt=Date.now();
let silenceMissCount=0;
let pendingHaanNaaQuestion=null;
let healthcareLaunchLock=false;
const PROACTIVE_WAIT_MS = 60000;
// Silent watchdog: three independent 20-second checkpoints.
// Listening 1 = first 20s, Listening 2 = second 20s, Listening 3 = third 20s.
// No microphone result is required for the timer to advance.
const SILENCE_CHECK_MS = 20000;

function setHealthWatchVisual(stage){
  const dot=document.getElementById("healthWatchDot");
  const dotR=document.getElementById("healthWatchDotRight");
  const label=document.getElementById("healthWatchStatus");
  [dot,dotR].forEach(el=>{ if(el) el.classList.remove("watch-20","watch-40","watch-60"); });
  if(stage===20){[dot,dotR].forEach(el=>el?.classList.add("watch-20")); if(label){label.textContent="HEALTH WATCH • 20";label.classList.remove("watch-done");}}
  else if(stage===40){[dot,dotR].forEach(el=>el?.classList.add("watch-40")); if(label){label.textContent="HEALTH WATCH • 40";label.classList.remove("watch-done");}}
  else if(stage===60){[dot,dotR].forEach(el=>el?.classList.add("watch-60")); if(label){label.textContent="HEALTH WATCH • 60 • LAUNCH";label.classList.remove("watch-done");}}
  else if(label){label.textContent="HEALTH WATCH • READY";label.classList.add("watch-done");}
}

function noteUserActivity(){
  lastUserActivityAt=Date.now();
  silenceCycleStartedAt=lastUserActivityAt;
  silenceMissCount=0;
  clearTimeout(silenceEntertainmentTimer);
  clearTimeout(silenceVisualTimer);
  setHealthWatchVisual(0);
  setStatus("🎤 Listening 1 • 0s — main sun rahi hoon");
  if(proactiveConversationActive) clearTimeout(proactiveResumeTimer);
  armSilenceWatcher();
}
function stopProactiveConversation(){
  proactiveConversationActive=false;
  proactiveRunning=false;
  proactiveLineIndex=0;
  clearTimeout(proactiveResumeTimer);
}
function scheduleProactiveNext(){
  clearTimeout(proactiveResumeTimer);
  if(!proactiveConversationActive || !voiceOn || isSleeping || playbackListeningLock || speakingActive) return;
  proactiveResumeTimer=setTimeout(()=>{
    if(proactiveConversationActive && Date.now()-lastUserActivityAt>=PROACTIVE_WAIT_MS && canAutoListen() && !captureActive){
      proactiveSpeakNext();
    }
  },PROACTIVE_WAIT_MS);
}
function getHealthcareDay(){
  const dayOfYear=Math.floor((Date.now()-new Date(new Date().getFullYear(),0,0))/86400000)-1;
  return (dayOfYear%14+14)%14;
}
const HEALTHCARE_14_DAYS=[
["Suprabhat Pitter. Uth gaye? Sabse pehle 1 glass paani piya ki nahi?","Aaj ka health mission: hydration aur 15 minute walk. Done?","Nashta skip mat karna. Protein aur fruit zaroor lena.","Main shaam ko check karungi; agar bhool gaye to yaad dilaungi."],
["Uth jao Pitter. Subah ka paani aur 5 minute stretching yaad hai?","Aaj 10 minute dhoop me baith lena.","Nashta me anda, paneer ya dal jaisa protein accha rahega.","Aaj body ko thoda movement dena hai."],
["Good morning Pitter. Aaj energy 1 se 10 tak kitni lag rahi hai?","Paani piyo aur 20 minute walk ya ghar me halka dance kar lo.","Nashta time par karna; dahi ya fruit add kar sakte ho.","Aaj ka goal simple hai: hydrated, active aur fresh rehna."],
["Utho Pitter. Aaj mantra hai: paani pehle, phone baad me.","5 minute shaant baithkar deep breathing kar lo.","Breakfast halka aur balanced rakho, jaise oats ya poha.","Aaj shaam ki walk miss mat karna."],
["Suprabhat Pitter. Weekend ho ya weekday, health ki chhutti nahi.","Aaj paani, fruit aur walk—teenon zaroori.","Thodi dhoop aur fresh air le lena.","Nashta skip kiya to main reminder zaroor dungi."],
["Uth jao Pitter. Aaj body ko thank you bolne ka din hai.","Paani, stretch aur 15 minute walk. Bas itna kar lo.","Nashta me protein zaroor rakho.","Aaj meetha aur junk thoda kam rakhna."],
["1 week complete Pitter. Well done.","Aaj bhi shuruaat 1 glass paani se.","Body ko rest bhi do aur thoda movement bhi.","Is hafte me jo sudhar hua hai, use continue rakhna."],
["Week 2 shuru Pitter. Nayi energy ke saath.","Paani, walk aur thodi sunlight ka combo try karo.","Plate me sabzi ya fruit ka colour add karo.","Aaj apne body signals ko ignore mat karna."],
["Good morning Pitter. Aaj pet halka aur hydration strong rakho.","Paani piyo aur 10 minute meditation try karo.","Nashta time par karo; bahut der mat karo.","Aaj ka focus: calm mind aur steady energy."],
["Suprabhat Pitter. Aaj posture bhi health ka part hai.","Phone use karte waqt gardan seedhi rakho.","15 minute walk ka target rakho.","Paani peete raho aur meals skip mat karo."],
["Morning check Pitter. Neend kaisi rahi?","Agar thakan hai to aaj pace halka rakho.","Breakfast me protein aur fruit add kar lo.","Health ka matlab sirf workout nahi, recovery bhi hai."],
["Suprabhat Pitter. Aaj hydration check se shuruaat karo.","Paani ki bottle paas rakho aur din bhar sip karte raho.","Lunch ko balanced rakho: dal, sabzi aur roti/rice jaisa simple meal.","Shaam ko thoda walk kar lena."],
["Good morning Pitter. Aaj bina jaldi ke body ko activate karo.","5 minute stretching aur ek glass paani se start karo.","Junk ke badle fruit ya nuts choose kar sakte ho.","Aaj apne liye thoda quiet time bhi rakho."],
["Suprabhat Pitter. Do hafte ka health cycle almost complete hai.","Aaj paani, movement aur timely meals par focus karo.","Apni energy ke hisaab se exercise rakho; overdo mat karo.","Consistency hi sabse bada health mission hai."]
];
const HEALTHCARE_EVENING=[
["Shaam ho gayi Pitter. Aaj paani kitna hua?","Walk hui? Nahi hui to 10 minute halka walk kar lo.","Junk ka mann ho to pehle paani aur fruit try karo.","Aaj ka score perfect nahi, consistent hona zaroori hai."],
["Evening check Pitter. Din ka hydration target kaisa raha?","Back ya neck tight lag raha ho to posture badlo aur halka stretch karo.","Snack me fruit, makhana ya roasted chana le sakte ho.","Phone se thoda break bhi health ka part hai."],
["Pitter, screen se 20-20-20 rule yaad rakho.","Shaam ka khana halka aur balanced rakho.","Aaj junk skip karna try karo.","Thoda fresh air aur slow breathing kar lo."],
["Ab tak paani theek hua Pitter? Agar kam hai to ab ek glass piyo.","Thak gaye ho to 10 minute rest lo.","Chai/coffee ko late evening me limit rakhna neend ke liye better hai.","Aaj ki walk miss mat karna."],
["Sach bolo Pitter, aaj paani kitna piya?","Cold drink ya chips ka mann ho to pehle paani piyo.","Doston ke saath time enjoy karo, bas meal balance rakho.","Raat ko sleep time ko zyada delay mat karna."],
["Hydration check Pitter. Paani regular peete raho.","Shoulder tight ho to halka movement karo.","Snack ke liye fruit ya nuts better choice hai.","Aaj thoda movement aur thoda relaxation dono chahiye."],
["Week review Pitter. Neend aur energy kaisi rahi?","Paani target hua to good job.","Shaam ko healthy dinner aur thoda walk kar lo.","Kal ke liye energy bachakar rakho."],
["Week 2 evening check. Back seedha, shoulders relaxed.","Har ghante thoda uthkar move kar lo.","Junk ko aaj bye bol do.","15 minute walk ho jaye to mission complete."],
["Pitter, sir dard ya thakan ho to paani aur rest ka dhyan rakho.","Screen se aankhon ko regular break do.","Dinner simple rakho.","Aaj body ko overwork mat karo."],
["Posture check Pitter. Phone ko bahut neeche rakhkar mat dekho.","Paani peete raho.","Shaam ko halka walk ya stretching kar lo.","Relaxation bhi daily routine ka hissa hai."],
["Energy check Pitter. Agar low hai to pace slow rakho.","Dinner time par karna better rahega.","Aaj thoda fresh air le lo.","Recovery ko priority do."],
["Paani reminder Pitter. Bottle refill kar lo.","Dinner me dal, sabzi aur roti/rice jaisa balanced option rakho.","Late-night heavy snacking avoid karna.","Aaj ki evening calmly finish karo."],
["Aaj ka health score khud ko do, Pitter.","Jo ek habit miss hui, use abhi chhote step se fix karo.","10 minute walk ya stretching kar lo.","Consistency perfection se zyada important hai."],
["Final evening check Pitter. Do hafte ki journey ka review karo.","Hydration, movement aur sleep me jo best raha use continue rakho.","Aaj dinner halka aur time par rakho.","Kal se cycle phir simple tareeke se chal sakta hai."]
];

const HEALTHCARE_NIGHT=[
["Raat ka time hai. Screen band karo aur aankhon ko aaram do.","Sone se pehle garam paani ya doodh pi sakte ho.","Kal ke liye paani ki bottle bhar ke rakh do.","Shubh ratri Pitter. 8 ghante ki neend pakki chahiye."],
["Raat 10 baje ke baad khana nahi Pitter.","Sone se 30 min pehle phone door rakh do.","Kal ka water target: 8 glass. Yaad hai na?","Shubh ratri. Body repair abhi hogi, so jao."],
["Pairon me tel laga lo. Neend acchi aayegi.","Kal ke kapde aur paani ki bottle ready rakho.","3 baar gehri saans lo... aur chhod do.","Shubh ratri Pitter. Kal aur healthy banna hai."],
["Dinner halka. Bahut der se mat khao.","Brush + tongue clean. Kal subah fresh rahoge.","Kal ka target: 8 glass paani + 7 ghante neend.","Shubh ratri. Main yahin hun, chinta mat karo."],
["Raat ko late mat sona. Sleep bhi health ka part hai.","Sone se pehle kal ka plan likh lo.","Paani ki bottle bed ke paas rakho.","Shubh ratri Pitter. Sweet dreams."],
["Raat 9 baje ke baad heavy khana band.","Garam doodh ya warm water le sakte ho.","Phone silent karo. Neend disturb nahi hogi.","Shubh ratri. Kal phir milte hain."],
["1 week complete Pitter. Aaj recovery ko priority do.","Sone se pehle 3 baar shukriya bolo.","Kal week 2 shuru hoga.","Shubh ratri. Achhi neend lo."],
["Raat ko screen time kam rakho.","Pairon ko thoda relax karo aur comfortable ho jao.","Kal subah paani aur walk yaad hai.","Shubh ratri. Body tumhara saath de rahi hai."],
["Dinner time par karna better rahega.","Sone se pehle thoda quiet time lo.","Kal 10 minute meditation try kar sakte ho.","Shubh ratri Pitter. Take care."],
["Posture aur neck ko relax karo.","Paani ki bottle kal ke liye ready rakho.","Aaj recovery ko ignore mat karna.","Shubh ratri. Kal fresh start karenge."],
["Aaj agar thakan hai to jaldi so jao.","Dinner halka rakho.","Kal breakfast aur paani time par karna.","Shubh ratri Pitter. Rest well."],
["Aaj ki hydration check yahin finish.","Kal bottle paas rakhna.","Phone thodi der door rakh do.","Shubh ratri. Subah fresh energy ke saath milenge."],
["Aaj body ko thoda recovery time do.","Fruit ya nuts ke baad late-night snacking avoid karo.","Kal stretching aur walk yaad rakhna.","Shubh ratri Pitter. Calm raho."],
["14 din ka health cycle almost complete hai.","Aaj sleep ko priority do.","Kal final health check hoga.","Shubh ratri Pitter. Tum bahut accha kar rahe ho."],
["14 din pure. Bahut accha kaam kiya Pitter.","Ab hydration, movement aur sleep ko routine bana kar rakho.","Aaj araam se so jao; body recovery deserve karti hai.","Shubh ratri Pitter. Nayi journey kal se."]
];


/* 14-DAY HAAN / NAA CARE GAME — one question per Morning/Evening/Night */
const HAA_NAA_GAME_14_DAYS = [
  [
    {question:"Kya aapne uthte hi 1 glass paani piya? Haa ya Naa?", yes:"Wah Pitter! Hydration king 👑 Aaj ka din accha jayega.", no:"Ayyo Pitter 😄 Abhi paani piyo aur phir 'Done' bolo. Body ko hydration chahiye."},
    {question:"Kya aaj 10 minute ke liye bahar gaye? Haa ya Naa?", yes:"Nice! Fresh air aur thodi movement — good job Pitter.", no:"Bas kamre me chipke rahe? 😄 Chalo thoda fresh air le aao."},
    {question:"Kya aaj 11 baje se pehle sone ka plan hai? Haa ya Naa?", yes:"Good boy! Sleep is recovery. Shubh ratri Pitter.", no:"Phir kal 'neend nahi aayi' mat bolna 😄 Phone thoda door rakho."}
  ],
  [
    {question:"Kya aaj breakfast skip nahi karoge? Haa ya Naa?", yes:"Shabash Pitter! Pet khush, energy khush.", no:"Nahi chalega 😄 Kuch simple aur balanced zaroor kha lena."},
    {question:"Kya aaj 6 glass paani complete hua? Haa ya Naa?", yes:"Hydration master! Proud of you Pitter.", no:"Pitterrr 😄 Ab ek glass paani se start karo, phir target complete karna."},
    {question:"Kya sone se pehle 15 minute phone door rakhoge? Haa ya Naa?", yes:"Waah! Discipline wale Pitter. Sweet dreams.", no:"Reels ko thoda break do 😄 Aankhon aur sleep ko bhi chance do."}
  ],
  [
    {question:"Kya aaj 15 minute walk ya dance karoge? Haa ya Naa?", yes:"Energy wale Pitter! Music chalao aur mission complete karo.", no:"Lazybones 😄 Room me hi ek gaane par dance kar lo."},
    {question:"Kya aaj junk food avoid kiya? Haa ya Naa?", yes:"Control king! Fruit ya nuts se victory celebrate karo.", no:"Haww Pitter 😄 Kal se nahi — aaj se next healthy choice karte hain."},
    {question:"Kya kal ke liye paani ki bottle ready hai? Haa ya Naa?", yes:"Future Pitter ready hai. Smart move.", no:"Subah 'paani nahi hai' mat bolna 😄 Abhi bhar ke rakho."}
  ],
  [
    {question:"Kya aaj dahi khaya? Haa ya Naa?", yes:"Nice! Balanced choices, Pitter.", no:"Koi baat nahi — next meal me dahi ya koi suitable healthy option try kar lena."},
    {question:"Kya aaj 15 minute walk hui? Haa ya Naa?", yes:"Excellent! Movement mission complete.", no:"Chalo 10 minute se start karte hain. Chhota step bhi progress hai."},
    {question:"Kya aaj jaldi sone ki koshish karoge? Haa ya Naa?", yes:"Perfect. Recovery mode ready.", no:"Thoda screen time kam karo, Pitter. Body ko rest chahiye."}
  ],
  [
    {question:"Kya aaj 10 minute dhoop li? Haa ya Naa?", yes:"Good! Fresh air bhi mil gayi, bonus.", no:"Agar comfortable ho to thodi der bahar fresh air le lena."},
    {question:"Kya aaj chai 2 cups se kam rahi? Haa ya Naa?", yes:"Nice control, Pitter. Balance maintained.", no:"Aaj se thoda limit try karte hain, especially late evening me."},
    {question:"Kya aaj phone thoda kam use kiya? Haa ya Naa?", yes:"Very good! Eyes ko bhi break mila.", no:"Ab thoda digital break le lo. Main bhi chup reh sakti hoon 😄"}
  ],
  [
    {question:"Kya aaj stretching ki? Haa ya Naa?", yes:"Super! Body ko movement mila.", no:"2-5 minute gentle stretching se start kar lo, Pitter."},
    {question:"Kya aaj raat relaxing routine rakha hai? Haa ya Naa?", yes:"Perfect. Calm evening, better recovery.", no:"Thoda slow down karo — music, breathing ya quiet time try karo."},
    {question:"Kya aaj gussa aane par pause liya? Haa ya Naa?", yes:"Proud of you Pitter. Calm is a superpower.", no:"Koi baat nahi. Agli baar 3 deep breaths ka rule try karenge."}
  ],
  [
    {question:"Kya 1 week ka health routine complete hua? Haa ya Naa?", yes:"One week! Well done Pitter 🎉", no:"Koi tension nahi. Aaj se ek habit ko strong banate hain."},
    {question:"Kya aaj khud ko healthy treat di? Haa ya Naa?", yes:"Deserved! Healthy celebration is the best.", no:"Fruit, music ya relaxing walk — ek simple treat choose karo."},
    {question:"Kya aaj enough sleep ka plan hai? Haa ya Naa?", yes:"Excellent. Recovery first.", no:"Aaj sleep ko priority do, Pitter."}
  ],
  [
    {question:"Kya aaj koi naya fruit try kiya? Haa ya Naa?", yes:"Fruit explorer! Nice choice Pitter.", no:"Kal ek naya fruit try karna. Variety bhi important hai."},
    {question:"Kya aaj 8000 steps ke aas-paas movement hua? Haa ya Naa?", yes:"Wow! Strong movement day.", no:"No pressure — abhi 10-15 minute walk bhi useful hai."},
    {question:"Kya aaj raat thodi kitab padhoge? Haa ya Naa?", yes:"Lovely. Screen-free wind-down activated.", no:"Koi baat nahi. Bas screen ko sone se pehle thoda break de dena."}
  ],
  [
    {question:"Kya aaj paani ke saath nimbu liya? Haa ya Naa?", yes:"Refreshing choice!", no:"Theek hai — normal paani bhi bilkul fine hai. Hydration pe focus rakho."},
    {question:"Kya aaj phone dekhte waqt back seedhi rakhi? Haa ya Naa?", yes:"Posture pro! Pitter approved 😄", no:"Phone thoda upar rakho aur shoulders relax karo."},
    {question:"Kya aaj late-night heavy khana avoid karoge? Haa ya Naa?", yes:"Good plan. Sleep ko bhi benefit milega.", no:"Dinner ko simple aur time par rakhne ki koshish karo."}
  ],
  [
    {question:"Kya aaj 10 glass paani ka target follow kiya? Haa ya Naa?", yes:"Hydration champion!", no:"Target ko force mat karo — apni needs aur routine ke hisaab se regular paani peete raho."},
    {question:"Kya aaj screen time kam rakha? Haa ya Naa?", yes:"Excellent digital balance.", no:"Ab 20-20-20 rule yaad rakho aur thoda break lo."},
    {question:"Kya aaj time par sone ka plan hai? Haa ya Naa?", yes:"Perfect. Good night routine locked.", no:"Chalo aaj thoda jaldi wind down karte hain."}
  ],
  [
    {question:"Kya aaj 5-10 minute meditation ya quiet breathing ki? Haa ya Naa?", yes:"Calm mind, strong Pitter.", no:"Sirf 3 slow breaths se start karo. Bas itna hi."},
    {question:"Kya aaj junk food avoid kiya? Haa ya Naa?", yes:"Excellent self-control!", no:"Koi guilt nahi — next snack ko healthier bana dete hain."},
    {question:"Kya aaj doston ke saath quality time mila? Haa ya Naa?", yes:"Social recharge complete! 😄", no:"Aaj ek friend ko hello bol do. Connection bhi important hai."}
  ],
  [
    {question:"Kya aaj sabzi khayi? Haa ya Naa?", yes:"Colourful plate, nice!", no:"Next meal me thodi sabzi add kar lena."},
    {question:"Kya aaj apna movement/steps target complete kiya? Haa ya Naa?", yes:"Mission complete Pitter!", no:"10 minute walk se restart kar lo."},
    {question:"Kya aaj phone ko thodi der silent rakha? Haa ya Naa?", yes:"Peace mode activated.", no:"Ab thoda quiet time try karo — notifications wait kar sakti hain."}
  ],
  [
    {question:"Kya kal ka plan aaj hi bana liya? Haa ya Naa?", yes:"Smart Pitter! Tomorrow is already prepared.", no:"Bas 2 important tasks likh do. Enough."},
    {question:"Kya aaj sugar ko thoda control kiya? Haa ya Naa?", yes:"Nice balance!", no:"No guilt. Agla choice thoda lighter rakhte hain."},
    {question:"Kya aaj 11 baje ke aas-paas sleep mode ka plan hai? Haa ya Naa?", yes:"Excellent. Recovery time!", no:"Thoda jaldi wind down karne ki koshish karo."}
  ],
  [
    {question:"Kya aapko lagta hai 14 din me ek achhi habit bani? Haa ya Naa?", yes:"That is a big win, Pitter!", no:"Koi problem nahi. Ek single habit choose karke continue karte hain."},
    {question:"Kya aap apni progress par proud ho? Haa ya Naa?", yes:"Mujhe bhi aap par naaz hai! ❤️", no:"Phir bhi aap yahan tak aaye — that itself counts."},
    {question:"Kya kal se bhi ye healthy routine continue karoge? Haa ya Naa?", yes:"Deal! Nayi journey officially start.", no:"No pressure. Kal ek chhota healthy step se shuru karenge."}
  ]
];


async function proactiveSpeakNext(){
  if(!proactiveConversationActive || !voiceOn || isSleeping || playbackListeningLock || speakingActive) return;
  if(Date.now()-lastUserActivityAt<PROACTIVE_WAIT_MS){ scheduleProactiveNext(); return; }
  const lines=getProactiveLines(); if(!lines?.length)return;
  if(proactiveLineIndex>=lines.length)proactiveLineIndex=0;
  const line=lines[proactiveLineIndex++]; proactiveRunning=true;
  appendMessage("assistant",line); setStatus("Pitter speaking...");
  await new Promise(resolve=>speak(line,resolve)); proactiveRunning=false;
  if(proactiveConversationActive && Date.now()-lastUserActivityAt>=PROACTIVE_WAIT_MS) scheduleProactiveNext();
}
function getHealthcareBlock(){
  const day=getHealthcareDay(), period=getProactivePeriod();
  if(period==='morning') return HEALTHCARE_14_DAYS[day]||HEALTHCARE_14_DAYS[0];
  if(period==='evening') return HEALTHCARE_EVENING[day]||HEALTHCARE_EVENING[0];
  return HEALTHCARE_NIGHT[day]||HEALTHCARE_NIGHT[0];
}
function pickExtrovertProactive(){
  const r=Math.random();
  if(r<0.30) return randomStory();
  if(r<0.48) return JOKES_COLLECTION_40[Math.floor(Math.random()*JOKES_COLLECTION_40.length)];
  if(r<0.82) return getHealthcareBlock().join(' ');
  return getProactiveLines().slice(0,4).join(' ');
}
function runProactiveSequence(){
  if(proactiveRunning || !voiceOn || isSleeping || playbackListeningLock || speakingActive)return;
  proactiveConversationActive=true; proactiveLineIndex=0; proactiveLastLine=""; proactiveSpeakNext();
}
function getHaanNaaQuestion(){
  const day=getHealthcareDay();
  const period=getProactivePeriod();
  const idx=period==='morning'?0:(period==='evening'?1:2);
  return HAA_NAA_GAME_14_DAYS[day]?.[idx] || HAA_NAA_GAME_14_DAYS[0][idx];
}
function runSilentHealthcare(){
  // This watchdog is completely independent of SpeechRecognition.
  // The visible Listening 1/2/3 state is driven only by elapsed time.
  if(!voiceOn || playbackListeningLock || healthcareLaunchLock){
    if(!healthcareLaunchLock) armSilenceWatcher();
    return;
  }

  const elapsed=Date.now()-silenceCycleStartedAt;
  if(elapsed < SILENCE_CHECK_MS){
    armSilenceWatcher();
    return;
  }

  const stage=Math.floor(elapsed/SILENCE_CHECK_MS);
  if(stage===1){
    silenceMissCount=1;
    setHealthWatchVisual(20);
    setStatus("🎤 Listening 2 • 20s — koi command nahi mila");
    armSilenceWatcher();
    return;
  }

  if(stage===2){
    silenceMissCount=2;
    setHealthWatchVisual(40);
    setStatus("🎤 Listening 3 • 40s — abhi bhi koi command nahi");
    armSilenceWatcher();
    return;
  }

  // Third silent window: automatic healthcare.
  silenceMissCount=3;
  setHealthWatchVisual(60);
  setStatus("🎤 Listening 3 • 60s — Healthcare launching...");
  launchAutomaticHealthcare();
}

function launchAutomaticHealthcare(){
  if(healthcareLaunchLock || !voiceOn || playbackListeningLock || speakingActive) return;
  healthcareLaunchLock=true;
  clearTimeout(silenceEntertainmentTimer);
  clearTimeout(silenceVisualTimer);
  clearTimeout(captureTimer);
  clearInterval(countdownTimer);
  clearTimeout(restartTimer);
  clearVoiceEngineTimers();

  // Invalidate the current recognition session before TTS. This prevents
  // recognition.onend from immediately starting another microphone session
  // while the healthcare sentence is being spoken.
  recognitionGeneration++;
  captureActive=false;
  captureClosing=false;
  recognitionRunning=false;
  isListening=false;
  try{ if(recognition) recognition.abort(); }catch(e){}
  recognition=null;
  if(micBtn) micBtn.classList.remove("listening");

  const lines=getHealthcareBlock();
  const question=getHaanNaaQuestion();
  const line=lines?.length ? lines[Math.floor(Math.random()*lines.length)] : "Pitter, thoda paani pee lijiye aur apni health ka dhyan rakhiye.";
  const includeQuestion=Math.random()<0.55;
  if(includeQuestion) pendingHaanNaaQuestion=question;
  const reply=includeQuestion ? `${line} ${question.question}` : line;

  appendMessage("assistant",reply);

  // Small delay gives Android Chrome time to finish aborting SpeechRecognition
  // before speechSynthesis is requested. No audible reminder is used for the
  // 20s/40s checkpoints; only this 60s launch speaks.
  setTimeout(()=>{
    if(!voiceOn){ healthcareLaunchLock=false; armSilenceWatcher(); return; }
    speak(reply,()=>{
      healthcareLaunchLock=false;
      lastUserActivityAt=Date.now();
      silenceCycleStartedAt=lastUserActivityAt;
      silenceMissCount=0;
      setHealthWatchVisual(0);
      setStatus("🎤 Listening 1 • naya silent cycle shuru");
      armSilenceWatcher();
    });
  },350);
}

function armSilenceWatcher(){
  clearTimeout(silenceEntertainmentTimer);
  clearTimeout(silenceVisualTimer);
  if(!voiceOn || healthcareLaunchLock) return;
  const elapsed=Date.now()-silenceCycleStartedAt;
  const nextBoundary=SILENCE_CHECK_MS*(Math.floor(elapsed/SILENCE_CHECK_MS)+1);
  const remaining=Math.max(250,nextBoundary-elapsed);
  silenceEntertainmentTimer=setTimeout(()=>runSilentHealthcare(),remaining);
}
setHealthWatchVisual(0);
setStatus("🎤 Listening 1 • 0s — main sun rahi hoon");
armSilenceWatcher();

/* TIME-BASED GREETING CALCULATOR */
function getTimeBasedGreeting() {
  const hour = new Date().getHours();
  if (hour >= 4 && hour < 12) return "Good Morning Pitter! ☀️";
  if (hour >= 12 && hour < 19) return "Good Afternoon Pitter! 🌤️";
  if (hour >= 19 && hour < 24) return "Good Night Pitter! 🌙";
  return "Good Night Pitter! 🌙";
}

/* 5 DAILY MOTIVATIONS ROTATOR */
function getDaily5Motivations() {
  const dayOfYear = Math.floor((new Date() - new Date(new Date().getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24));
  const startIndex = (dayOfYear * 5) % MOTIVATION_BANK_124.length;
  let selected = [];
  for (let i = 0; i < 5; i++) {
    selected.push(MOTIVATION_BANK_124[(startIndex + i) % MOTIVATION_BANK_124.length]);
  }
  return selected;
}

/* JOKE SEQUENCER & STOP HANDLER */
function handleJokeSequence() {
  if (!isJokeModeActive) return;

  if (currentJokeIndex < JOKES_COLLECTION_40.length) {
    const currentJoke = JOKES_COLLECTION_40[currentJokeIndex];
    currentJokeIndex++;
    triggerExpression("laugh");
    appendMessage("assistant", currentJoke);
    speak(currentJoke, () => {
      if (isJokeModeActive) {
        setTimeout(handleJokeSequence, 1200);
      }
    });
  } else {
    isJokeModeActive = false;
    currentJokeIndex = 0;
    const endMsg = "Sare chutkule khatam ho gaye Pitter! Aasha hai aapka mood fresh ho gaya hoga.";
    appendMessage("assistant", endMsg);
    speak(endMsg);
  }
}

/* MASTER BRAIN QUERY PROCESSOR (FIXED ALL REPETITION ISSUES) */
function currentTimeReply() {
  const now=new Date();
  const h=now.getHours(), m=now.getMinutes();
  const hh=((h+11)%12)+1;
  const mm=String(m).padStart(2,"0");
  const suffix=h>=12?"PM":"AM";
  return `Abhi time ${hh}:${mm} ${suffix} ho raha hai Pitter. ⏰`;
}

const INTENT_VARIANTS={
  time:["time","kitna baje","kitne baje","what time","samay","waqt","abhi kya time","abhi time","time kya","time kitna","baje kitna","taime","taim","tyme","tame","teim"],
  alexaOn:["alexa mode on","alexa mode chalu","alexa mode start","alexa ko on","alexa on","alexa chalu","alexa mode","alexa activate","alexa active"],
  beliOn:["beli mode on","beli mode chalu","beli mode start","beli ko on","beli on","beli chalu","beli mode","beli activate","beli active"],
  how:["kaise ho","theek ho","thik ho","how are you","kya kar rahi","kya kar rahe","what are you doing"],
  thanks:["thank you","thanks","shukriya","dhanyawad"],
  greeting:["hi","hello","hey","hii","namaste","good morning","good afternoon","good evening","good night"]
};
function hasIntent(q, arr){ return arr.some(v=>q===v || q.includes(v)); }
function containsTimeIntent(raw,q){
  if(hasIntent(q,INTENT_VARIANTS.time)) return true;
  // Fuzzy phonetic tokens: taime/taim + kitna/baje etc.
  const t=/\b(taim|taime|timee|tyme|tame|teim|time)\b/.test(q);
  const k=/\b(kitna|kitne|kitta|baje|samay|waqt)\b/.test(q);
  return t || (k && /(abhi|kya|bata|batao|hai|ho)/.test(q));
}
function modeIntent(q, mode){
  const name=mode==='alexa'?'alexa':'beli';
  const word=new RegExp('\\b'+name+'\\b').test(q);
  const action=/(mode|on|chalu|start|activate|active|karo|kardo|kar do|switch|wapas)/.test(q);
  return word && action;
}


/* ================================================================
   V22 LOCAL FAST KNOWLEDGE + VOICE HEARING HARDENING
   ================================================================ */
const FAST_KNOWLEDGE = [
  {
    a:"मेरा नाम EV है। आप मुझे EV या Beli कह सकते हैं।",
    p:["your name","what is your name","ur name","tumhara naam kya hai","tumhara nam kya h","aapka naam kya hai","aapka nam kya h","tumhara naam kya he","tum kon ho","who are you","who r u","aap kon ho","tum kaun ho","tum kon hoo"]
  },
  {a:"मैं EV हूँ, आपकी personal voice assistant। आप मुझे Beli भी बुला सकते हैं।",p:["tum kaun ho","who are you","who r u","aap kon ho","tum kon hoo"]},
  {a:"हाँ, मैं आपको सुन रही हूँ। बोलिए।",p:["can you hear me","kya tum mujhe sun rahi ho","meri awaz sun pa rhi ho","kya tum mujhe sunn rhi hoo","meri awaaz sun rahi ho"]},
  {a:"मैं आपकी बात सुन रही हूँ और आपकी मदद के लिए तैयार हूँ।",p:["what are you doing","tum kya kar rahi ho","abhi kya kr rhi ho","tum kya kr rhi hoo"]},
  {a:"हाँ, मैं हिंदी, Hinglish और English समझने की कोशिश कर सकती हूँ।",p:["do you understand hindi","tum hindi samajhti ho","hinglish samajhti ho","can you understand hinglish","english samajhti ho","can you understand english","hindi bol sakti ho","can you speak hindi"]},
  {a:"भारत के प्रधानमंत्री नरेंद्र मोदी हैं।",p:["who is the prime minister of india","prime minister of india","india pm","india ka pm","bharat ke pm kaun hain","bharat ka pm kaun h","bharat ke pradhan mantri","india ke pradhan mantri kon hai","india pm kon hai","india pm kaun h"]},
  {a:"भारत की राष्ट्रपति द्रौपदी मुर्मू हैं।",p:["who is president of india","president of india","india president","bharat ke rashtrapati","india ke president kon hai"]},
  {a:"भारत की राजधानी नई दिल्ली है।",p:["capital of india","india capital","bharat ki rajdhani","india ki rajdhani kya h","bharat ka capital kya hai"]},
  {a:"भारत में 28 राज्य और 8 केंद्र शासित प्रदेश हैं।",p:["how many states in india","india me kitne states","bharat mein kitne rajya","how many union territories in india","india me kitne union territories","india me kitne uts"]},
  {a:"भारत की मुद्रा भारतीय रुपया है और उसका चिन्ह ₹ है।",p:["currency of india","indian currency","india ki currency","bharat ki mudra","rupee symbol","indian rupee sign","rupaye ka symbol"]},
  {a:"भारत का राष्ट्रीय पशु बाघ है।",p:["national animal of india","india ka national animal","bharat ka rashtriya pashu","india ka national janwar"]},
  {a:"भारत का राष्ट्रीय पक्षी मोर है।",p:["national bird of india","india ka national bird","bharat ka rashtriya pakshi","india ka national panchi"]},
  {a:"भारत का राष्ट्रीय फूल कमल है।",p:["national flower of india","india ka national flower","bharat ka rashtriya phool","india ka national ful"]},
  {a:"भारत का राष्ट्रीय फल आम है।",p:["national fruit of india","india ka national fruit","bharat ka rashtriya fal","india ka national fruit kya h"]},
  {a:"भारत का राष्ट्रीय वृक्ष बरगद है।",p:["national tree of india","india ka national tree","bharat ka rashtriya vriksh","bharat ka national ped"]},
  {a:"भारत सरकार ने किसी खेल को आधिकारिक राष्ट्रीय खेल घोषित नहीं किया है।",p:["national sport of india","india ka national sport","bharat ka rashtriya khel","national game of india"]},
  {a:"भारत का राष्ट्रीय गान ‘जन गण मन’ है।",p:["national anthem of india","india ka national anthem","bharat ka rashtriya gaan"]},
  {a:"भारत का राष्ट्रीय गीत ‘वंदे मातरम्’ है।",p:["national song of india","bharat ka rashtriya geet","india national song"]},
  {a:"क्षेत्रफल के आधार पर राजस्थान भारत का सबसे बड़ा राज्य है।",p:["largest state of india by area","area mein sabse bada rajya","india ka biggest state","sabse bada state area se"]},
  {a:"क्षेत्रफल के आधार पर गोवा भारत का सबसे छोटा राज्य है।",p:["smallest state india by area","area mein smallest state","india ka sabse chota rajya","smallest state konsa"]},
  {a:"भारत में गंगा को सामान्यतः सबसे लंबी नदी माना जाता है।",p:["longest river in india","india ki longest river","bharat ki sabse lambi nadi","sabse long river india"]},
  {a:"भारत की सबसे ऊँची चोटी कंचनजंगा है।",p:["highest peak in india","india highest peak","bharat ki sabse unchi choti","india ki highest mountain peak"]},
  {a:"माउंट एवरेस्ट दुनिया का सबसे ऊँचा पर्वत है।",p:["highest mountain in world","world highest peak","duniya ka sabse uncha mountain","duniya ka highest pahad"]},
  {a:"प्रशांत महासागर दुनिया का सबसे बड़ा महासागर है।",p:["largest ocean","biggest ocean in world","sabse bada ocean","duniya ka largest mahasagar"]},
  {a:"एशिया दुनिया का सबसे बड़ा महाद्वीप है।",p:["largest continent","biggest continent in world","sabse bada continent","duniya ka largest continent"]},
  {a:"ऑस्ट्रेलिया सबसे छोटा महाद्वीप है।",p:["smallest continent","smallest continent in world","sabse chota continent","duniya ka smallest mahadweep"]},
  {a:"चंद्रमा पृथ्वी का प्राकृतिक उपग्रह है।",p:["earth natural satellite","natural satellite of earth","prithvi ka prakritik upgrah","dharti ka satellite"]},
  {a:"सूर्य एक तारा है।",p:["what is the sun","sun kya hai","surya kya hota hai","sun planet hai kya"]},
  {a:"पृथ्वी सूर्य के चारों ओर परिक्रमा करती है।",p:["earth revolves around what","prithvi kis ke around ghumti","earth kiske chakkar lagati","dharti kis ke charo taraf"]},
  {a:"पृथ्वी अपने अक्ष पर लगभग 24 घंटे में एक चक्कर पूरा करती है।",p:["earth rotation time","earth takes to rotate","prithvi apne axis par kitne ghante","how long earth takes to rotate"]},
  {a:"पानी का रासायनिक सूत्र H₂O है।",p:["water chemical formula","pani ka formula","h2o kya hota","water formula kya"]},
  {a:"ऑक्सीजन का रासायनिक चिन्ह O है।",p:["oxygen symbol","oxygen ka sign kya","chemical symbol of oxygen","oxyzen ka symbol"]},
  {a:"सोने का रासायनिक चिन्ह Au है।",p:["gold chemical symbol","gold ka symbol","sone ka chemical sign","chemical symbol of gold"]},
  {a:"एक वयस्क मानव शरीर में सामान्यतः 206 हड्डियाँ होती हैं।",p:["human body bones kitni","how many bones in human body","insan me kitni haddiyan","human bones kitne"]},
  {a:"त्वचा मानव शरीर का सबसे बड़ा अंग है।",p:["largest organ human body","human body largest organ","insan ka sabse bada organ","biggest organ body"]},
  {a:"हृदय का मुख्य काम रक्त को पूरे शरीर में पंप करना है।",p:["heart ka kaam kya","function of heart","dil kya karta hai","heart ka main function"]},
  {a:"हीमोग्लोबिन के कारण रक्त लाल दिखाई देता है।",p:["blood red why","khoon lal kyu hota","why blood is red","blood ka color red kyun"]},
  {a:"पौधे प्रकाश संश्लेषण की प्रक्रिया से अपना भोजन बनाते हैं।",p:["plants food kaise banate","how plants make food","paudhe khana kaise banate","plant food making process"]},
  {a:"पौधे प्रकाश संश्लेषण में कार्बन डाइऑक्साइड का उपयोग करते हैं।",p:["photosynthesis gas","plant photosynthesis mein kaunsi gas","which gas plants use","photosynthesis me gas kya"]},
  {a:"मनुष्य श्वसन के लिए मुख्यतः ऑक्सीजन लेते हैं।",p:["humans breathe which gas","insan kaunsi gas leta","breathing gas kya","we breathe which gas"]},
  {a:"CPU को सामान्यतः कंप्यूटर का ‘दिमाग’ कहा जाता है।",p:["computer brain kya hai","brain of computer","computer ka dimag","cpu computer brain"]},
  {a:"CPU का पूरा नाम Central Processing Unit है।",p:["cpu full form","full form of cpu","cpu ka pura naam","cpu ka full form kya"]},
  {a:"RAM का पूरा नाम Random Access Memory है।",p:["ram full form","full form of ram","ram ka pura naam","ram ka matlab computer"]},
  {a:"WWW का पूरा नाम World Wide Web है।",p:["www full form","full form of www","triple w full form","www ka pura naam"]},
  {a:"GPS का पूरा नाम Global Positioning System है।",p:["gps full form","full form of gps","gps ka pura naam","gps ka matlab kya"]},
  {a:"AI का पूरा नाम Artificial Intelligence है।",p:["ai full form","artificial intelligence full form","ai ka pura naam","artificial intelijence kya"]},
  {a:"भारत का संविधान 26 जनवरी 1950 को लागू हुआ।",p:["constitution of india came into force when","bharat ka samvidhan kab lagu hua","india constitution date","samvidhan kab lagu hua tha"]},
  {a:"भारत का स्वतंत्रता दिवस 15 अगस्त को मनाया जाता है।",p:["independence day india","bharat ka independence day","india azadi day kab","swatantrata divas kab hai"]},
  {a:"भारत में गणतंत्र दिवस 26 जनवरी को मनाया जाता है।",p:["republic day india","bharat ka republic day","ganatantra divas kab","republic day date india"]},
  {a:"गांधी जयंती 2 अक्टूबर को मनाई जाती है।",p:["gandhi jayanti date","mahatma gandhi birthday","gandhi ji ka birthday kab","gandhi jayanti kab hai"]},
  {a:"भारत के पहले प्रधानमंत्री जवाहरलाल नेहरू थे।",p:["first pm of india","india first prime minister","bharat ke pehle pradhan mantri","india ka first pm kaun"]},
  {a:"भारत की पहली महिला प्रधानमंत्री इंदिरा गांधी थीं।",p:["first woman pm india","india first female prime minister","bharat ki first mahila pm","pehli lady pm india"]},
  {a:"ताजमहल आगरा, उत्तर प्रदेश में स्थित है।",p:["taj mahal kaha hai","where is taj mahal","tajmahal kis city mein","taj mahal kahan located"]},
  {a:"कुतुब मीनार दिल्ली में स्थित है।",p:["qutub minar kaha hai","where is qutub minar","qutub minar kis city","kutub minar kahan"]},
  {a:"गेटवे ऑफ इंडिया मुंबई में स्थित है।",p:["gateway of india kaha","where is gateway of india","gateway india kis city","gateway of india kahan hai"]},
  {a:"ज़रूर। बोलिए, मैं सुन रही हूँ।",p:["are you ready","tum ready ho","kya aap tayar ho","tum redy ho"]},
  {a:"बिल्कुल। बताइए, आपको किस चीज़ में मदद चाहिए?",p:["can you help me","meri madad karogi","kya tum help kar sakti ho","meri hlp krogi"]},
  {a:"हाँ, मैं आपको सुन रही हूँ। बोलिए।",p:["can you hear me","kya tum mujhe sun rahi ho","meri awaz sun pa rhi ho","kya tum mujhe sunn rhi hoo"]}
];

function fastKnowledgeLookup(text){
  const q=normalizeCommandText(text).toLowerCase().replace(/[^a-z0-9₹\s]/g," ").replace(/\s+/g," ").trim();
  if(!q) return null;
  let best=null, bestScore=0;
  for(const item of FAST_KNOWLEDGE){
    for(const p0 of item.p){
      const p=normalizeCommandText(p0).toLowerCase().replace(/[^a-z0-9₹\s]/g," ").replace(/\s+/g," ").trim();
      if(!p) continue;
      if(q===p) return item.a;
      const qw=new Set(q.split(" ").filter(x=>x.length>1));
      const pw=p.split(" ").filter(x=>x.length>1);
      let hit=0; for(const w of pw) if(qw.has(w)) hit++;
      const coverage=hit/Math.max(1,pw.length);
      const contains=(q.includes(p)||p.includes(q))?1:0;
      const score=coverage*0.75+contains*0.25;
      if(score>bestScore){bestScore=score;best=item.a;}
    }
  }
  return bestScore>=0.58?best:null;
}

const LOTUS_PARi_STORY = `The Legend of Pari and the Lotus Blossom. Apunar babe ek khub dhuniya notun kahini. Eka ansolot Pari naamor ejoni dhuniya sowaali aasil. Tai-or maa-deuta nai, tair mahi-maa aru baiekor logot thakisil. Mahi-maa sob homoyote Pari-k dukh disil. Ahiboloi thaka Bihu utsobor babe, mahi-mai Pari-k jor koi paharor kakhote thaka nodir pora pani aniboloi pathale, pisot tai-k gupon koi maathir tolot lukai thole. Kintu Pari-r aatma mori nogol. Kisuman din pisot, heitu nodir parat ek khub dhuniya Ronga Padum fuli uthil. Heitu nodiye di jetiya ekhon naaw paar hoi goisil, naaworiya-hoote aashorjo hoi sale. Jetiya naaworiya-hoote heitu fulto suyii saboloi gol, fultoe geet gaiboloi dhorile: O Naworiya brothers, do not pluck my stem. I am not just a flower, nor a hidden gem. My stepmother tried to bury me in the clay, but like the blooming lotus, I rise today. Heitu geet huni raaj-kumar aahi fulto suyii dile aru tai-k morom korile. Lagote lagote fulto naikiya hol aru Pari aakou ejoni dhuniya suwali hoi thiyo hol. Pari-ye tai-or mahi-maa-k khoma korile, aru tai aaponar jibonot soboke morom aru aashirbad dile. Moral: Jikono dukh-kosto aahileu, aaponar bhal mon aru aatma-k kunue harabo narare. Tumi padum fulor dore aakou fuli uthiba.`;

const KISA_GOTAMI_STORY = `Gautam Buddhar eti anupam kahini hol Kisa Gotami aru horiyoh gutir golpo, jito amak mritiu aru dukhor hosa gyan diye. Kisa Gotamir Kahini. Edin Kisa Gotami namor egoraki dukhi air ekmatro xontan hothate mrittiu mukhot pore. Putror xukot unmad hoi teo mrito xontantuk kolat loi gaonr ghore ghore olai zay, zate kunubai teor xontanuk jiyai tulibo pare. Manuhbure buzi pale ze Kisa Gotami xukot pagol hoise. Tetia ejon biyoktiye teok Gautam Buddhar kaxoloi jaboloi poramorxo diye. Kisa Gotamiye mrit xontantok loi Buddhar osoroloi zay aru kandi kandi koy, He Probhu, mor xontanuk jiyai tulok. Buddhai xantobhabe kole, Zoa, zi ghoror manuh ketiyao mora nai, xei ghoror pora olop soriyoh guti ani diya mok. Kisa Gotamiye axa loi ghore ghore ghurile. Kintu teo zito ghorotei gol, tatei xuniboloi paii ze tat kunuba nohoi kunuba ejon atmiyor mritiu hoise—karobar pitri, karobar putro, karobar xwami ba potni morise. Eta ghoro bisari napale zot mritiu hoa nai. Oboxexot teo buzi pale ze mritiu xokolore babe dhrubo xotyo aru niscit. Teo mrit xontanok kobor di ubhoti ahil aru Buddhar horon lole. Noitik hikha: Mritiu sironton xotyo: Zi jonmo hoise, tar mritiu niscit. Dukhor pora mukti: Anoro dukhu ase, kewol nizor dukhok dangor buli bhabi nijok bhangi pelabo nalage. Xanti labh: Bastob xotyok mani lolehe mone xanti pai.`;

const STORY_BANK = [
  {id:"pari-lotus", title:"Pari aru Ronga Padum", text:LOTUS_PARi_STORY},
  {id:"kisa-gotami", title:"Kisa Gotami aru Horiyoh Guti", text:KISA_GOTAMI_STORY}
];
let lastStoryId = localStorage.getItem("beli_last_story_id") || "";
let storyOrder = [];
let storyCursor = 0;

const STORY_TRIGGER_VARIANTS = [
  "story","stories","tell me a story","kahani","kahaani","kakhani","khani","kahini",
  "kaahini","kahene","kaheyini","kaheini","kahani sunao","kahani suna do","ek kahani",
  "story sunao","story suna do","kahani bolo","aur sunao","aur kahani","alag story",
  "different story","another story","second story","dusri story","doosri story","next story",
  "next kahani","next kahini","new story","nayi story","nayi kahani"
];
const NEXT_STORY_VARIANTS = [
  "next story","next kahani","next kahini","second story","another story","different story",
  "alag story","aur sunao","aur kahani","dusri story","doosri story","new story","nayi story","nayi kahani"
];

function levenshteinDistance(a,b){
  a=String(a||""); b=String(b||"");
  if(a===b)return 0;
  if(!a.length)return b.length;
  if(!b.length)return a.length;
  let prev=Array.from({length:b.length+1},(_,i)=>i);
  for(let i=1;i<=a.length;i++){
    const cur=[i];
    for(let j=1;j<=b.length;j++){
      cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));
    }
    prev=cur;
  }
  return prev[b.length];
}
function weakPhraseMatch(x,v){
  if(x===v || x.includes(v)) return true;
  const tokens=x.split(/\s+/), vt=v.split(/\s+/);
  if(vt.length===1){
    return tokens.some(t=>t.length>=4 && levenshteinDistance(t,v)<=Math.max(1,Math.floor(v.length*0.25)));
  }
  return vt.every(w=>x.split(/\s+/).some(t=>t.length>=4 && levenshteinDistance(t,w)<=Math.max(1,Math.floor(w.length*0.25))));
}
function isNextStoryIntent(q){
  const x=String(q||"").toLowerCase().trim();
  return NEXT_STORY_VARIANTS.some(v=>weakPhraseMatch(x,v));
}
function isStoryIntent(q){
  const x=String(q||"").toLowerCase().trim();
  return STORY_TRIGGER_VARIANTS.some(v=>weakPhraseMatch(x,v));
}
function randomStory(){
  let candidates=STORY_BANK.filter(st=>st.id!==lastStoryId);
  if(!candidates.length)candidates=STORY_BANK.slice();
  const st=candidates[Math.floor(Math.random()*candidates.length)];
  lastStoryId=st.id;
  localStorage.setItem("beli_last_story_id",st.id);
  return st.text;
}
function nextStory(){
  if(STORY_BANK.length<2)return randomStory();
  // Randomized order: never force serial 1->2->1. Shuffle when needed.
  if(storyCursor>=storyOrder.length){
    storyOrder=STORY_BANK.map((_,i)=>i).sort(()=>Math.random()-0.5);
    if(storyOrder.length>1 && STORY_BANK[storyOrder[0]].id===lastStoryId){
      [storyOrder[0],storyOrder[1]]=[storyOrder[1],storyOrder[0]];
    }
    storyCursor=0;
  }
  const st=STORY_BANK[storyOrder[storyCursor++]];
  lastStoryId=st.id;
  localStorage.setItem("beli_last_story_id",st.id);
  return st.text;
}

function analyzeBrainResponse(query) {
  const raw=normalizeVoiceText(query);
  const q=normalizeCommandText(raw);

  // Highest priority: exact utility/command intents BEFORE greetings or generic memory.
  if(containsTimeIntent(raw,q)) return currentTimeReply();
  // Name identity intent: support English, Roman Hinglish and Hindi-ASR variants.
  if(/\b(your name|what is your name|ur name|who are you|who r u|tumhara naam|tumara naam|aapka naam|mera naam kya|what your name|your nam)\b/i.test(q)){
    return "Mera naam EV hai. Aap mujhe EV ya Beli keh sakte hain.";
  }
  const fastAnswer=fastKnowledgeLookup(q);
  if(fastAnswer) return fastAnswer;

  if(modeIntent(q,'alexa')) {
    toggleAlexaMode(true);
    return "Alexa mode on ho gaya Pitter. Ab tum bolo, main dhyan se sun rahi hoon.";
  }
  if(modeIntent(q,'beli')) {
    toggleAlexaMode(false);
    triggerExpression("love");
    return "Beli mode on ho gaya Pitter. Main yahin hoon, bolo kya karna hai? 💕";
  }

  if(q.includes("stop") || q.includes("ruk ja") || q.includes("bas karo") || q.includes("सो जाओ")) {
    stopProactiveConversation();
    isJokeModeActive=false; currentJokeIndex=0;
    try{window.speechSynthesis.cancel();}catch(e){}
    return "Thik hai Pitter, ruk gayi. Ab bolo.";
  }
  if(isSleeping){
    isSleeping=false; sleepBadge.classList.add("hidden"); triggerExpression("love");
    return "Main jaag gayi Pitter. Tumhari awaaz sunke achha laga. 💕";
  }
  if(q.includes("sleep") || q.includes("chup") || q.includes("सो जाओ")){
    stopProactiveConversation();
    isSleeping=true; sleepBadge.classList.remove("hidden"); triggerExpression("sleep");
    return "Thik hai Pitter, main thodi der sleep mode mein ja rahi hoon. Bulaoge toh aa jaungi.";
  }
  if(hasIntent(q,INTENT_VARIANTS.greeting)){
    triggerExpression("love");
    return `${getTimeBasedGreeting()} Pitter. Main bilkul theek hoon, tum kaise ho?`;
  }
  if(hasIntent(q,INTENT_VARIANTS.how)){
    triggerExpression("love");
    return "Mujhe sunkar achha laga Pitter. Main bhi theek hoon, aur abhi tumhari baat sun rahi hoon. 💕";
  }
  if(hasIntent(q,INTENT_VARIANTS.thanks)) return "Anytime Pitter. Main yahin hoon. 😊";

  // STORY INTENT: stories are randomized and never forced into a fixed serial order.
  if(isStoryIntent(q)){
    isJokeModeActive=false; currentJokeIndex=0;
    try{ window.speechSynthesis.cancel(); }catch(e){}
    triggerExpression("calm");
    return isNextStoryIntent(q) ? nextStory() : randomStory();
  }

  // Entertainment / mood intent: boring, sad or mood-off requests start jokes.
  if(q.includes("joke") || q.includes("chutkula") || q.includes("bored") || q.includes("boring") || q.includes("borning") || q.includes("sad mode") || q.includes("mood kharab") || q.includes("mood off") || q.includes("mood down") || q.includes("sad hoon") || q.includes("sad hu")){
    isJokeModeActive=true; currentJokeIndex=0; triggerExpression("laugh");
    return "Arre mood theek karte hain ab 😄 Sad mat ho, main hu na.";
  }
  if(q.includes("motivation") || q.includes("motivate")){
    triggerExpression("love");
    return `Pitter, aaj ka simple rule: dheere chalo, lekin rukna mat. Tum jo seekh rahe ho, wahi tumhe aage le jayega. 💪`;
  }
  if(q.includes("kiss") || q.includes("pyaar") || q.includes("pyar")){
    triggerExpression("kiss"); return "MWAH! 💋 Ye sweet flying kiss tumhare liye Pitter.";
  }
  for(let key in injectedMemory){ if(q.includes(normalizeCommandText(key))) return injectedMemory[key]; }

  const known = lookupKnowledge(q);
  if (known) return known;

  // Human-like general fallback: varied and context-aware, never asks a question every turn.
  const generic=[
    `Haan Pitter, samajh rahi hoon. Tumhari baat dhyan se sun rahi hoon.`,
    `Achha Pitter, ye baat interesting hai. Main tumhare saath hoon.`,
    `Got it Pitter. Main repeat nahi karungi, seedha tumhari baat ke hisab se jawab dungi.`,
    `Hmm, samajh gayi Pitter. Chalo isko calmly dekhte hain.`,
    `Haan, main sun rahi hoon Pitter. Tum jo keh rahe ho uska context yaad rakh rahi hoon.`
  ];
  const idx=Math.floor(Math.random()*generic.length);
  return generic[idx];
}

let knowledgePack = [];
try {
  fetch("knowledge.json", {cache:"no-store"}).then(r=>r.ok?r.json():null).then(data=>{ knowledgePack=data?.items||[]; }).catch(()=>{});
} catch(e) {}
function lookupKnowledge(q){
  if(!knowledgePack.length) return null;
  const nq=normalizeCommandText(q);
  let best=null, score=0;
  for(const item of knowledgePack){
    const iq=normalizeCommandText(item.q);
    const words=iq.split(/\s+/).filter(w=>w.length>2);
    let sc=0;
    for(const w of words) if(nq.includes(w)) sc++;
    if(sc>score){score=sc;best=item.a;}
  }
  return score>=2?best:null;
}


/* ================================================================
   ULTRA PRO v13 ADDITIONS
   - Local offline music via IndexedDB
   - Daily random offline track (once/day)
   - Radio URL streaming
   - Live weather via Open-Meteo + browser geolocation
   - Developer AI endpoint + remote config
   - Safe remote configuration (JSON only; no remote JS execution)
   ================================================================ */
function initAudioDB(){
  return new Promise((resolve,reject)=>{
    if(audioDB) return resolve(audioDB);
    if(!window.indexedDB) return reject(new Error("IndexedDB unavailable"));
    const req=indexedDB.open("beli_ultra_audio",1);
    req.onupgradeneeded=()=>{ const db=req.result; if(!db.objectStoreNames.contains("songs")) db.createObjectStore("songs",{keyPath:"id",autoIncrement:true}); };
    req.onsuccess=()=>{audioDB=req.result;resolve(audioDB);};
    req.onerror=()=>reject(req.error);
  });
}
async function saveOfflineSong(title,file){
  const db=await initAudioDB();
  await new Promise((resolve,reject)=>{
    const tx=db.transaction("songs","readwrite");
    tx.objectStore("songs").add({title:title||file.name,blob:file,mime:file.type,createdAt:Date.now()});
    tx.oncomplete=resolve; tx.onerror=()=>reject(tx.error);
  });
  await refreshOfflinePlaylist();
}
async function getOfflineSongs(){
  const db=await initAudioDB();
  return await new Promise((resolve,reject)=>{
    const tx=db.transaction("songs","readonly"), req=tx.objectStore("songs").getAll();
    req.onsuccess=()=>resolve(req.result||[]); req.onerror=()=>reject(req.error);
  });
}
async function deleteOfflineSong(id){
  const db=await initAudioDB();
  await new Promise((resolve,reject)=>{
    const tx=db.transaction("songs","readwrite"); tx.objectStore("songs").delete(id);
    tx.oncomplete=resolve; tx.onerror=()=>reject(tx.error);
  });
  refreshOfflinePlaylist();
}
async function playOfflineSong(song){
  if(!song) return false;
  setPlaybackListeningLock(true);
  const url=URL.createObjectURL(song.blob);
  audioPlayer.src=url;
  songTitle.innerText="🎵 "+song.title;
  musicContainer.classList.remove("hidden");
  try{
    await audioPlayer.play();
    setStatus("🎵 Music playing. Mic ON hai; lyrics/background audio commands nahi banenge.");
    if(canAutoListen() && !captureActive) setTimeout(startVoiceCapture,250);
    return true;
  }catch(e){
    setStatus("Song ready. Tap Play once to allow audio.");
    return false;
  }
}
async function playRandomOfflineSong(){
  const songs=await getOfflineSongs();
  if(!songs.length){ speak("Meri offline song library abhi khaali hai. Studio se song save kar dijiye."); return; }
  const song=songs[Math.floor(Math.random()*songs.length)];
  await playOfflineSong(song);
  localStorage.setItem("beli_daily_music_date",new Date().toLocaleDateString("en-CA"));
}
async function refreshOfflinePlaylist(){
  if(!playlistView) return;
  try{
    const songs=await getOfflineSongs();
    songCount.innerText=songs.length;
    playlistView.innerHTML="";
    songs.forEach(song=>{
      const row=document.createElement("div");
      row.style.cssText="display:flex;gap:6px;align-items:center;margin:5px 0;";
      row.innerHTML=`<span style="flex:1">${escapeHtml(song.title)}</span>`;
      const play=document.createElement("button"); play.className="btn"; play.innerText="▶";
      play.onclick=()=>playOfflineSong(song);
      const del=document.createElement("button"); del.className="btn"; del.innerText="✕";
      del.onclick=()=>deleteOfflineSong(song.id);
      row.append(play,del); playlistView.appendChild(row);
    });
  }catch(e){}
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));}

function renderRadioStations(){
  if(!radioStationSelect)return;
  radioStationSelect.innerHTML="";
  radioStations.sort((a,b)=>Number(a.channel||0)-Number(b.channel||0));
  radioStations.forEach((st,i)=>{const o=document.createElement("option");o.value=i;o.textContent=`CH ${st.channel||i+1} — ${st.name||st.url}`;radioStationSelect.appendChild(o);});
}
async function playRadio(url,name){
  if(!url) throw new Error("radio url missing");
  setPlaybackListeningLock(true);
  const rn=document.getElementById("radioNowPlaying");
  if(rn)rn.textContent="📻 Connecting • "+(name||"Radio");
  setStatus("📻 Connecting to radio...");
  try{
    audioPlayer.pause();
    audioPlayer.removeAttribute("src");
    audioPlayer.load();
    audioPlayer.src=String(url).trim();
    audioPlayer.preload="auto";
    audioPlayer.loop=false;
    songTitle.innerText="📻 "+(name||"Radio");
    musicContainer.classList.remove("hidden");

    const waitForAudio=()=>new Promise((resolve,reject)=>{
      let settled=false;
      const cleanup=()=>{
        clearTimeout(timer);
        audioPlayer.removeEventListener("error",onError);
        audioPlayer.removeEventListener("stalled",onStalled);
        audioPlayer.removeEventListener("canplay",onReady);
        audioPlayer.removeEventListener("playing",onReady);
      };
      const finish=(ok,err)=>{
        if(settled)return; settled=true; cleanup(); ok?resolve():reject(err||new Error("radio stream failed"));
      };
      const onReady=()=>finish(true);
      const onError=()=>finish(false,new Error("radio stream error"));
      const onStalled=()=>setStatus("📻 Radio buffering...");
      const timer=setTimeout(()=>finish(false,new Error("radio stream timeout")),15000);
      audioPlayer.addEventListener("canplay",onReady,{once:true});
      audioPlayer.addEventListener("playing",onReady,{once:true});
      audioPlayer.addEventListener("error",onError,{once:true});
      audioPlayer.addEventListener("stalled",onStalled);
      audioPlayer.play().catch(err=>finish(false,err));
    });
    await waitForAudio();
    setPlaybackListeningLock(false);
    if(rn)rn.textContent="📻 LIVE • "+(name||"Radio");
    setStatus("📻 Radio playing. Voice commands available.");
    if(canAutoListen() && !captureActive) setTimeout(()=>startVoiceCapture(false),250);
    return true;
  }catch(err){
    setPlaybackListeningLock(false);
    try{audioPlayer.pause();}catch(e){}
    if(rn)rn.textContent="📻 Stream unavailable";
    setStatus("📻 Radio stream load nahi hua. Station URL/connection check kijiye.");
    throw err;
  }
}
function stopRadio(){
  try{audioPlayer.pause();audioPlayer.removeAttribute("src");audioPlayer.load();}catch(e){}
  setPlaybackListeningLock(false);
  const rn=document.getElementById("radioNowPlaying");
  if(rn)rn.textContent="📻 No station playing";
  if(canAutoListen()&&!captureActive) setTimeout(()=>startVoiceCapture(false),250);
}
async function radioCommand(q){
  const urlMatch=q.match(/(?:radio|station|stream)(?:\s+(?:play|chalao|start))?\s+(?:url\s+)?(https?:\/\/\S+)/i);
  if(urlMatch){
    try{await playRadio(urlMatch[1],"Custom Radio");return "Radio stream start kar diya.";}
    catch(e){return "Radio URL load nahi ho paya. Stream URL check kijiye.";}
  }
  const ch=q.match(/(?:channel|ch|station)\s*(?:number\s*)?(\d+)/i);
  if(ch){
    const num=Number(ch[1]),st=radioStations.find(x=>Number(x.channel)===num);
    if(!st)return `Channel ${num} saved nahi hai.`;
    try{await playRadio(st.url,st.name);return `Channel ${num}, ${st.name||"Radio"} chala diya.`;}
    catch(e){return `Channel ${num} play nahi ho paya. Station URL check kijiye.`;}
  }
  if(/radio|station|stream/.test(q)){
    if(radioStations.length){
      const st=radioStations[Math.floor(Math.random()*radioStations.length)];
      try{await playRadio(st.url,st.name);return `${st.name||"Radio"} stream start kar diya.`;}
      catch(e){return `${st.name||"Radio"} stream load nahi ho paya. Studio me URL check kijiye.`;}
    }
    return "Radio ke liye pehle Studio mein station URL save kijiye.";
  }
  return null;
}
async function getLiveWeather(){
  const WEATHER_CACHE_KEY = "beli_weather_location";
  let lat=null, lon=null, source="gps";
  let cached=null;

  try { cached=JSON.parse(localStorage.getItem(WEATHER_CACHE_KEY)||"null"); } catch(e) {}

  // Prefer a fresh browser GPS position. Cached coordinates are only a fallback.
  const getGPS = () => new Promise((resolve,reject)=>{
    if(!navigator.geolocation) return reject(new Error("geolocation unavailable"));
    navigator.geolocation.getCurrentPosition(
      p=>resolve(p),
      e=>reject(e),
      {enableHighAccuracy:true, timeout:12000, maximumAge:120000}
    );
  });

  try{
    const pos=await getGPS();
    lat=Number(pos.coords.latitude);
    lon=Number(pos.coords.longitude);
    if(Number.isFinite(lat) && Number.isFinite(lon)){
      localStorage.setItem(WEATHER_CACHE_KEY,JSON.stringify({
        lat,lon,savedAt:Date.now()
      }));
    }
  }catch(gpsError){
    // If GPS fails even after permission is granted, use the last valid GPS
    // location before falling back to approximate IP geolocation.
    if(cached && Number.isFinite(Number(cached.lat)) && Number.isFinite(Number(cached.lon))){
      lat=Number(cached.lat); lon=Number(cached.lon); source="cached-gps";
    }else{
      try{
        const ipCtl=new AbortController();
        const ipTimer=setTimeout(()=>ipCtl.abort(),7000);
        const ipRes=await fetch("https://ipwho.is/",{cache:"no-store",signal:ipCtl.signal});
        clearTimeout(ipTimer);
        const ipData=await ipRes.json();
        if(ipData && ipData.success && Number.isFinite(Number(ipData.latitude)) && Number.isFinite(Number(ipData.longitude))){
          lat=Number(ipData.latitude); lon=Number(ipData.longitude); source="ip";
        }
      }catch(ipError){}
    }
  }

  if(!Number.isFinite(lat) || !Number.isFinite(lon)){
    throw new Error("location unavailable");
  }

  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),10000);
  let r;
  try{
    r=await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&current=temperature_2m,apparent_temperature,weather_code,relative_humidity_2m,wind_speed_10m,precipitation&hourly=precipitation_probability&forecast_days=1&timezone=auto`,
      {cache:"no-store",signal:controller.signal}
    );
  }finally{
    clearTimeout(timer);
  }
  if(!r.ok) throw new Error(`weather fetch failed: ${r.status}`);
  const d=await r.json();
  if(!d.current) throw new Error("weather current data missing");

  const code=d.current.weather_code;
  const map={
    0:"clear sky",1:"mostly clear",2:"partly cloudy",3:"overcast",
    45:"foggy",48:"foggy",51:"light drizzle",53:"drizzle",55:"heavy drizzle",
    61:"light rain",63:"rain",65:"heavy rain",
    71:"light snow",73:"snow",75:"heavy snow",
    80:"rain showers",81:"rain showers",82:"heavy rain showers",
    95:"thunderstorm",96:"thunderstorm",99:"thunderstorm"
  };

  // Match precipitation probability to Open-Meteo's returned local hour,
  // rather than assuming the device timezone is identical to the weather timezone.
  let pop=null;
  const hourlyTimes=d.hourly?.time||[];
  if(Array.isArray(hourlyTimes) && Array.isArray(d.hourly?.precipitation_probability)){
    const nowMs=Date.now();
    let best=-1, bestDiff=Infinity;
    hourlyTimes.forEach((t,i)=>{
      const ms=Date.parse(t);
      if(Number.isFinite(ms)){
        const diff=Math.abs(ms-nowMs);
        if(diff<bestDiff){bestDiff=diff;best=i;}
      }
    });
    if(best>=0) pop=d.hourly.precipitation_probability[best];
  }

  const temp=Math.round(Number(d.current.temperature_2m));
  const feels=Math.round(Number(d.current.apparent_temperature));
  const humidity=Math.round(Number(d.current.relative_humidity_2m));
  const wind=Math.round(Number(d.current.wind_speed_10m));
  const rainNow=Number(d.current.precipitation);

  let reply=`Pitter, maine live weather data check kiya. Abhi ${map[code]||"weather condition available"} hai, temperature ${temp}°C aur feels like ${feels}°C hai.`;
  if(Number.isFinite(humidity)) reply+=` Humidity ${humidity}% hai.`;
  if(Number.isFinite(wind)) reply+=` Hawa ki speed ${wind} km/h hai.`;
  if(Number.isFinite(pop)) reply+=` Agle available hour ka rain chance ${Math.round(pop)}% hai.`;
  if(Number.isFinite(rainNow) && rainNow>0) reply+=` Abhi precipitation ${rainNow} mm hai.`;
  if(source==="ip") reply+=" GPS response nahi mila, isliye location approximate network location se li gayi hai.";
  return reply;
}

function getLiveCalendarReply(q=""){
  const now=new Date();
  const day=now.toLocaleDateString("en-IN",{weekday:"long"});
  const date=now.toLocaleDateString("en-IN",{day:"numeric",month:"long",year:"numeric"});
  const time=now.toLocaleTimeString("en-IN",{hour:"numeric",minute:"2-digit",hour12:true});
  if(/\b(time|kitna baje|abhi time|samay|waqt)\b/i.test(q)){
    return `Abhi ${time} ho raha hai, Pitter.`;
  }
  if(/\b(date|tarikh|tareekh|aaj ki date)\b/i.test(q)){
    return `Aaj ${day}, ${date} hai, Pitter.`;
  }
  return `Aaj ${day}, ${date} hai aur abhi ${time} ho raha hai, Pitter.`;
}

async function remoteAIReply(userText){
  if(!apiEndpoint) return null;
  const system = `${customSystemPrompt}\n\nDeveloper rules: natural Hinglish/Hindi; concise; do not invent live data; user is addressed as Pitter.`;
  const payload={model:apiModel||undefined,messages:[{role:"system",content:system},{role:"user",content:userText}],prompt:system,input:userText};
  const headers={"Content-Type":"application/json"};
  if(apiKey) headers.Authorization=`Bearer ${apiKey}`;
  const r=await fetch(apiEndpoint,{method:"POST",headers,body:JSON.stringify(payload)});
  if(!r.ok) throw new Error(`AI server ${r.status}`);
  const d=await r.json();
  const text=d?.choices?.[0]?.message?.content || d?.choices?.[0]?.text || d?.output_text || d?.response || d?.reply || d?.message;
  return typeof text==="string"?text.trim():null;
}
async function loadDeveloperConfig(){
  if(!remoteConfigUrl) throw new Error("Remote config URL not set");
  const r=await fetch(remoteConfigUrl,{cache:"no-store"});
  if(!r.ok) throw new Error(`Config ${r.status}`);
  const cfg=await r.json();
  remoteConfig=cfg||{};
  if(typeof cfg.systemPrompt==="string" && cfg.systemPrompt.trim()){ customSystemPrompt=cfg.systemPrompt.trim(); localStorage.setItem("beli_system_prompt",customSystemPrompt); if(systemPromptInput)systemPromptInput.value=customSystemPrompt; }
  if(typeof cfg.aiEndpoint==="string"){ apiEndpoint=cfg.aiEndpoint.trim(); localStorage.setItem("beli_api_endpoint",apiEndpoint); if(document.getElementById("apiEndpoint"))document.getElementById("apiEndpoint").value=apiEndpoint; }
  if(Array.isArray(cfg.radioStations)){radioStations=cfg.radioStations.filter(x=>x&&x.url);localStorage.setItem("beli_radio_stations",JSON.stringify(radioStations));renderRadioStations();}
  if(Array.isArray(cfg.dialogues)){ window.BELI_REMOTE_DIALOGUES=cfg.dialogues; }
  if(document.getElementById("updateStatus")) document.getElementById("updateStatus").innerText=`Config loaded: ${cfg.version||"unversioned"}`;
  return cfg;
}
async function checkRemoteUpdate(){
  try{
    const cfg=await loadDeveloperConfig();
    const msg=cfg.updateUrl?`Update available: ${cfg.updateUrl}`:`Developer config is current. App ${APP_VERSION}, remote ${cfg.version||"unknown"}.`;
    if(document.getElementById("updateStatus"))document.getElementById("updateStatus").innerText=msg;
    return msg;
  }catch(e){if(document.getElementById("updateStatus"))document.getElementById("updateStatus").innerText="Update check failed: "+e.message;return "Update check failed.";}
}
async function maybeDailyRandomMusic(){
  if(!dailyRandomMusicEnabled) return;
  const today=new Date().toLocaleDateString("en-CA");
  if(lastDailyMusicDate===today) return;
  const key="beli_daily_music_target";
  let target=Number(localStorage.getItem(key)||0);
  const now=Date.now();
  if(!target || target<now){
    const d=new Date(); d.setHours(10+Math.floor(Math.random()*10),Math.floor(Math.random()*60),0,0);
    target=d.getTime();
    if(target<=now) target+=24*60*60*1000;
    localStorage.setItem(key,String(target));
  }
  const delay=Math.min(Math.max(target-now,1000),2147483647);
  setTimeout(async()=>{
    try{
      const songs=await getOfflineSongs();
      if(!songs.length) return;
      const ok=await playRandomOfflineSong();
      if(ok!==false){ lastDailyMusicDate=new Date().toLocaleDateString("en-CA"); localStorage.setItem("beli_daily_music_date",lastDailyMusicDate); localStorage.removeItem(key); }
    }catch(e){}
  },delay);
}

function looksLikeWeather(q){
  const x=normalizeCommandText(q);
  return /\b(weather|weatherupdate|update|mausam|temperature|temp|barish|baarish|rain|forecast|humidity|hawa|garmi|thand|weather)\b/i.test(x)
    || /वेदर|मौसम|बारिश|तापमान|पूर्वानुमान|नमी/.test(String(q||''));
}
function looksLikeCalendar(q){return /\b(calendar|date|tarikh|tareekh|aaj ki date|today|day|kaun sa din|konsa din|what day|time|kitna baje|abhi time|samay|waqt)\b/i.test(q);}
function looksLikeMusic(q){
  const x=normalizeCommandText(q);
  return /\b(play|bajao|chalao|song|gaana|gana|music|track|favorite|fav)\b/i.test(x)
    || /सॉन्ग|सांग|प्ले|गाना|म्यूजिक|संगीत/.test(String(q||''));
}
function looksLikeRadio(q){
  const x=normalizeCommandText(q);
  return /\b(radio|station|stream|channel)\b/i.test(x)
    || /रेडियो|स्टेशन|चैनल|स्ट्रीम/.test(String(q||''));
}


function levenshtein(a,b){
  a=String(a||""); b=String(b||"");
  const d=Array.from({length:a.length+1},(_,i)=>i);
  for(let j=1;j<=b.length;j++){
    let prev=d[0]; d[0]=j;
    for(let i=1;i<=a.length;i++){
      const cur=d[i];
      d[i]=Math.min(d[i]+1,d[i-1]+1,prev+(a[i-1]===b[j-1]?0:1));
      prev=cur;
    }
  }
  return d[a.length];
}
function wakeWordKind(text){
  const q=normalizeCommandText(text).toLowerCase();
  const tokens=q.split(/[^a-z]+/).filter(Boolean);
  const alexa=/\b(alexa|aleksa|aleksha|alekhsa|alecksa|alixa|aliksa|alesha|aelkxa|alehsa|alesa|alexaah|a lex a|a lek sa)\b/i;
  const beli=/\b(beli|bel|belee|beley|belii|bili|bilee|belly|belle|belli|bele|vele|yeli|yele|baili|bailly|belya)\b/i;
  if(alexa.test(q)) return "alexa";
  if(beli.test(q)) return "beli";
  if(/\b(ev|evee|evy|evi|eevee)\b/i.test(q) || /ईवी|इवी/i.test(String(text||""))) return "ev";
  // Catch close ASR outputs even when punctuation/spacing is strange.
  for(const t of tokens){
    if(t.length>=3 && levenshtein(t,"alexa")<=2) return "alexa";
    if(t.length>=3 && levenshtein(t,"beli")<=2) return "beli";
    if(t.length>=2 && levenshtein(t,"ev")<=1) return "ev";
  }
  return null;
}
function wakeResponse(kind){
  if(kind==="ev"){
    return {reply:"Haan Pitter, EV sun rahi hoon. Boliye.", enable:false};
  }
  if(kind==="alexa"){
    return {
      reply:"Alexa mode on. Alexa mode चालू है। मैं आपकी voice commands सुन रही हूँ। बोलिए।",
      enable:true
    };
  }
  return {
    reply:"Beli mode on. Beli mode चालू है। मैं आपकी voice commands सुन रही हूँ। बोलिए।",
    enable:false
  };
}

async function processQueryEnhanced(text, fromVoice=false){
  noteUserActivity();
  const clean=normalizeVoiceText(text), q=normalizeCommandText(text);
  if(!clean || pendingVoiceProcess) return;

  // Android WebView speech recognition can occasionally emit a phantom one-word
  // greeting from ambient audio. Do not let that trigger an unsolicited "hi"
  // reply during the silent healthcare watchdog window. Wake words remain valid.
  if(fromVoice && /^(hi|hii|hello|hey)$/.test(q) && !wakeWordKind(clean)){
    setStatus("🎤 Listening... main sun rahi hoon");
    return;
  }

  // Resolve the latest Haa/Naa wellness question before normal intent handling.
  if(pendingHaanNaaQuestion && /^(haan|ha|yes|y|naa|na|no|n)$/.test(q)){
    const answer=/^(haan|ha|yes|y)$/.test(q);
    const reply=answer ? pendingHaanNaaQuestion.yes : pendingHaanNaaQuestion.no;
    pendingHaanNaaQuestion=null;
    appendMessage("user",fromVoice?romanizeHindi(clean):clean);
    appendMessage("assistant",reply);
    noteUserActivity();
    speak(reply);
    return;
  }

  // Wake words are prefixes. V25 previously returned here and consumed
  // commands such as "EV radio chalao".
  const wake=wakeWordKind(clean);
  // Sleep mode remains passively listening for wake words (Alexa/Beli/EV).
  // Any other speech is ignored until a valid wake word is heard.
  if(isSleeping && !wake){ pendingVoiceProcess=false; return; }
  let effectiveClean=clean;
  let effectiveQ=q;
  if(wake){
    const wr=wakeResponse(wake);
    if(isSleeping){
      isSleeping=false;
      sleepBadge.classList.add("hidden");
      triggerExpression("love");
    }
    toggleAlexaMode(wr.enable);
    effectiveClean=clean.replace(/^(?:hey\s+)?(?:alexa|aleksa|aleksha|alekhsa|alecksa|alixa|aliksa|alesha|aelkxa|alehsa|beli|bel|belee|beley|belii|bili|bilee|belly|belle|belli|bele|vele|yeli|yele|baili|bailly|belya|ev)\b[,:;\s-]*/i,"").trim();
    effectiveQ=normalizeCommandText(effectiveClean);
    if(!effectiveClean){
      pendingVoiceProcess=true;
      appendMessage("user",romanizeHindi(clean));
      appendMessage("assistant",wr.reply);
      setStatus("Speaking..."); updateLiveDisplayMood("speaking");
      speak(wr.reply,()=>{pendingVoiceProcess=false;});
      return;
    }
  }
  if (fromVoice && proactiveConversationActive) {
    clearTimeout(proactiveResumeTimer);
    proactiveRunning=false;
  }
  pendingVoiceProcess=true;
  appendMessage("user",fromVoice?romanizeHindi(effectiveClean):effectiveClean);
  if(fromVoice) setStatus(`🧠 Decoding: "${romanizeHindi(effectiveClean)}"`);
  else setStatus("Thinking...");
  updateLiveDisplayMood("decoding"); updateLiveDisplayMood("thinking");
  try{
    let reply=null;
    if(looksLikeWeather(effectiveQ)){
      setStatus("🌦️ Weather command decoded...");
      try{reply=await getLiveWeather();}
      catch(e){
        reply="Pitter, live weather service se data abhi nahi aa raha. Location permission aur internet connection check karke phir try kijiye.";
      }
    }
    else if(looksLikeCalendar(effectiveQ)){ reply=getLiveCalendarReply(effectiveQ); }
    else if(looksLikeMusic(effectiveQ)){
      const songs=await getOfflineSongs().catch(()=>[]);
      if(songs.length){
        const named=songs.find(x=>effectiveQ.includes(normalizeCommandText(x.title)));
        if(named){await playOfflineSong(named);reply=`${named.title} play kar diya.`;}
        else {await playRandomOfflineSong();reply=`Offline library se ${songTitle.innerText.replace(/^🎵 /,"")} play kar diya.`;}
      }else reply="Offline song library abhi khaali hai. Studio se MP3/WAV save kijiye.";
    } else if(looksLikeRadio(effectiveQ)){
      reply=await radioCommand(effectiveQ);
    }
    if(!reply && !looksLikeMusic(effectiveQ) && !looksLikeRadio(effectiveQ) && !looksLikeWeather(effectiveQ)){
      // Commands/greetings should remain local; conversational questions can use developer AI.
      const local=analyzeBrainResponse(effectiveQ);
      const localish=hasIntent(effectiveQ,INTENT_VARIANTS.greeting)||hasIntent(effectiveQ,INTENT_VARIANTS.how)||hasIntent(effectiveQ,INTENT_VARIANTS.thanks)||/^(time|samay|date|tarikh|stop|ruk|sleep|chup|joke|chutkula|motivation|kiss|pyar|pyaar)\b/i.test(effectiveQ);
      if(localish) reply=local;
      else if(apiEndpoint){ try{reply=await remoteAIReply(effectiveClean);}catch(e){reply=`AI server connect nahi ho paya (${e.message}). Local assistant ready hai.`;}}
      else reply=local;
    }
    if(reply){
      appendMessage("assistant",reply);
      setStatus("Speaking..."); updateLiveDisplayMood("speaking");
      speak(reply, ()=>{
        if(proactiveConversationActive && canAutoListen()){
          // Start a fresh 8-second user window after the answer.
          setTimeout(()=>{ if(proactiveConversationActive && !manualStopRequested && canAutoListen() && !captureActive) startVoiceCapture(false); },80);
        }
      });
    }
  }catch(e){
    appendMessage("assistant","Ek chhota sa system issue hua. Local mode abhi bhi ready hai.");
    speak("Ek chhota sa system issue hua. Local mode abhi bhi ready hai.");
  }
  finally{pendingVoiceProcess=false;}
}

function processQuery(text, fromVoice=false) {
  noteUserActivity();
  const clean=normalizeVoiceText(text);
  const commandText=normalizeCommandText(text);
  if(!clean || pendingVoiceProcess) return;
  pendingVoiceProcess=true;
  appendMessage("user", fromVoice ? romanizeHindi(clean) : clean);
  setStatus("Thinking..."); updateLiveDisplayMood("thinking");
  // No artificial long delay. Voice commands should answer immediately after capture.
  setTimeout(()=>{
    let reply=null;
    try{ reply=analyzeBrainResponse(commandText || clean); }catch(err){ reply="Sorry Pitter, ek chhota sa brain error hua. Ab main ready hoon."; }
    pendingVoiceProcess=false;
    if(reply){
      appendMessage("assistant",reply);
      setStatus("Speaking..."); updateLiveDisplayMood("speaking");
      speak(reply, () => {
        // Keep hands-free conversation alive: after one user turn, give the user
        // the mic again quickly; do not require another button press.
        if(!manualStopRequested && canAutoListen() && !captureActive) setTimeout(startVoiceCapture,120);
      });
    } else {
      setTimeout(()=>{ if(!manualStopRequested && voiceOn && !speakingActive) startVoiceCapture(); },250);
    }
  },40);
}

function appendMessage(role, content) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  div.innerText = content;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function toggleAlexaMode(enableAlexa) {
  isAlexaMode = enableAlexa;
  if (isAlexaMode) {
    document.body.className = "alexa-theme";
    document.getElementById("assistantTitle").innerText = "Alexa AI Engine ⚡";
    document.getElementById("alexaConvertBtn").innerText = "💖 Beli";
    setTimeout(()=>{ if(!manualStopRequested && voiceOn && !speakingActive && !captureActive && !playbackListeningLock) startVoiceCapture(false); },120);
  } else {
    document.body.className = "beli-theme";
    document.getElementById("assistantTitle").innerText = "Beli ♾️ (Mrs. Spiderman)";
    document.getElementById("alexaConvertBtn").innerText = "⚡ Alexa";
    if(canAutoListen() && !captureActive) setTimeout(()=>startVoiceCapture(false),120);
  }
}

/* INITIALIZATION */
function initSystem() {
  startEyeBlinking();
  triggerExpression("love");
  
  systemPromptInput.value = customSystemPrompt;
  lastProcessedVoice="";
  const greeting = `${getTimeBasedGreeting()} System active hai. Main yahin hoon, Pitter. Aapki awaaz ka intezar kar rahi hoon.`;
  document.getElementById("welcomeMsg").innerText = greeting;
  setTimeout(() => {
    speak(greeting, () => {
      // First user window starts automatically immediately after Pitter's greeting.
      setTimeout(() => {
        if(!captureActive && !speakingActive && voiceOn && !playbackListeningLock){
          startVoiceCapture(false);
        }
      },120);
    });
    // SpeechSynthesis callbacks can be delayed on some Android WebViews; never let
    // that prevent the first microphone window from opening.
    setTimeout(() => {
      if(!captureActive && !speakingActive && voiceOn && !playbackListeningLock){
        startVoiceCapture(false);
      }
    },5000);
  }, 800);

  // Hands-free startup watchdog: if Android delays speechSynthesis.onend,
  // the first listening window must still become available automatically.
  clearTimeout(voiceAutoStartTimer);
  voiceAutoStartTimer=setTimeout(()=>{
    if(!captureActive && !manualStopRequested && voiceOn && !playbackListeningLock){
      if(speakingActive && Date.now()-speechStartedAt>9000){
        try{window.speechSynthesis.cancel();}catch(e){}
        speakingActive=false;
        if(!isAlexaMode) faceAvatar.classList.remove("speaking");
      }
      if(!speakingActive) startVoiceCapture(false);
    }
  },7000);

  // If the user does not speak in the first 8-second window, the
  // morning/evening/night assistant sentence cycle begins automatically.
  // No immediate monologue: proactive content waits for 5 minutes of user silence.
  lastUserActivityAt=Date.now();
  armSilenceWatcher();
}

/* EVENT LISTENERS */
saveSystemPromptBtn.addEventListener("click", () => {
  const val = systemPromptInput.value.trim();
  if (val) {
    customSystemPrompt = val;
    localStorage.setItem("beli_system_prompt", val);
    alert("System Prompt Instructions Saved Successfully!");
  }
});

document.getElementById("alexaConvertBtn").addEventListener("click", () => toggleAlexaMode(!isAlexaMode));
document.getElementById("studioToggleBtn").addEventListener("click", () => studioModal.classList.remove("hidden"));
document.getElementById("closeStudioBtn").addEventListener("click", () => studioModal.classList.add("hidden"));

document.getElementById("devModeBtn").addEventListener("click", () => devModal.classList.remove("hidden"));
document.getElementById("closeDevBtn").addEventListener("click", () => devModal.classList.add("hidden"));

document.getElementById("submitPinBtn").addEventListener("click", () => {
  if (document.getElementById("pinInput").value === "aj7555&@pbidi") {
    document.getElementById("devControls").classList.remove("hidden");
    alert("Unlocked!");
  } else {
    alert("Incorrect PIN!");
  }
});

document.getElementById("savePromptBtn")?.addEventListener("click", () => {
  const k = document.getElementById("promptKeyword").value.trim().toLowerCase();
  const a = document.getElementById("promptAnswer").value.trim();
  if (k && a) {
    injectedMemory[k] = a;
    localStorage.setItem("beli_injected_memory", JSON.stringify(injectedMemory));
    alert("Memory Injected!");
  }
});

sendBtn.addEventListener("click", () => {
  const val = textInput.value.trim();
  if (val) { processQueryEnhanced(val); textInput.value = ""; }
});

textInput.addEventListener("keydown", (e) => { if (e.key === "Enter") sendBtn.click(); });

micBtn.addEventListener("click", () => {
  if (!SpeechRecognition) return alert("Android Chrome mein Speech Recognition support/permission check karein.");
  if (captureActive) {
    // Button press is an explicit stop. Do not auto-restart after this cycle.
    stopVoiceCapture(true);
  } else {
    manualStopRequested=false;
    startVoiceCapture(true);
  }
});

document.getElementById("voiceToggleBtn").addEventListener("click", () => {
  voiceOn = !voiceOn;
  if(voiceOn){ manualStopRequested=false; handsFreeDesired=true; }
  else handsFreeDesired=false;
  document.getElementById("voiceToggleBtn").innerText = voiceOn ? "🔊" : "🔇";
  if (!voiceOn) {
    stopProactiveConversation();
    window.speechSynthesis.cancel();
    try{ if(recognition) recognition.abort(); }catch(e){}
    captureActive=false; captureClosing=false;
    clearTimeout(captureTimer); clearInterval(countdownTimer);
    setStatus("🔇 Voice assistant muted.");
  } else {
    if(!speakingActive && !captureActive) startVoiceCapture(true);
  }
});


/* PRO v13 EVENT BINDINGS */
const apiEndpointInput=document.getElementById("apiEndpoint");
const apiKeyInput=document.getElementById("apiKey");
const apiModelInput=document.getElementById("apiModel");
const remoteConfigInput=document.getElementById("remoteConfigUrl");
const saveApiBtn=document.getElementById("saveApiBtn");
const loadRemoteConfigBtn=document.getElementById("loadRemoteConfigBtn");
const checkUpdateBtn=document.getElementById("checkUpdateBtn");
const radioContainer=document.getElementById("radioContainer");
const radioChannelInput=document.getElementById("radioChannelInput");
const radioUrlInput=document.getElementById("radioUrlInput");
const radioNameInput=document.getElementById("radioNameInput");
const playRadioBtn=document.getElementById("playRadioBtn");
const saveRadioBtn=document.getElementById("saveRadioBtn");
const stopRadioBtn=document.getElementById("stopRadioBtn");
const editRadioBtn=document.getElementById("editRadioBtn");
const deleteRadioBtn=document.getElementById("deleteRadioBtn");
const radioStationSelect=document.getElementById("radioStationSelect");

document.getElementById("playRadioBtn")?.addEventListener("click",()=>playRadio(radioUrlInput?.value.trim(),radioNameInput?.value.trim()));
document.getElementById("stopRadioBtn")?.addEventListener("click",stopRadio);
document.getElementById("saveRadioBtn")?.addEventListener("click",()=>{
  const st={channel:Math.max(1,Number(radioChannelInput?.value||0)||(radioStations.length+1)),
    url:radioUrlInput?.value.trim()||"",name:radioNameInput?.value.trim()||"Radio"};
  if(!st.url)return alert("Radio stream URL enter kijiye.");
  const existing=radioStations.findIndex(x=>Number(x.channel)===Number(st.channel));
  if(existing>=0)radioStations[existing]=st;else radioStations.push(st);
  localStorage.setItem("beli_radio_stations",JSON.stringify(radioStations));
  renderRadioStations(); alert("Station offline save ho gaya.");
});
document.getElementById("editRadioBtn")?.addEventListener("click",()=>{
  const idx=Number(radioStationSelect?.value), st=radioStations[idx];
  if(!st)return alert("Pehle station select kijiye.");
  const next={channel:Math.max(1,Number(radioChannelInput?.value||st.channel)),url:radioUrlInput?.value.trim()||st.url,name:radioNameInput?.value.trim()||st.name};
  radioStations[idx]=next; localStorage.setItem("beli_radio_stations",JSON.stringify(radioStations)); renderRadioStations();
});
document.getElementById("deleteRadioBtn")?.addEventListener("click",()=>{
  const idx=Number(radioStationSelect?.value);
  if(!Number.isInteger(idx)||!radioStations[idx])return alert("Pehle station select kijiye.");
  radioStations.splice(idx,1); localStorage.setItem("beli_radio_stations",JSON.stringify(radioStations)); renderRadioStations();
});

renderRadioStations();

if(apiEndpointInput) apiEndpointInput.value=apiEndpoint;
if(apiKeyInput) apiKeyInput.value=apiKey;
if(apiModelInput) apiModelInput.value=apiModel;
if(remoteConfigInput) remoteConfigInput.value=remoteConfigUrl;

saveApiBtn?.addEventListener("click",()=>{
  apiEndpoint=apiEndpointInput.value.trim(); apiKey=apiKeyInput.value.trim(); apiModel=apiModelInput.value.trim();
  localStorage.setItem("beli_api_endpoint",apiEndpoint);
  localStorage.setItem("beli_api_key",apiKey);
  localStorage.setItem("beli_api_model",apiModel);
  alert("AI server settings saved locally.");
});
loadRemoteConfigBtn?.addEventListener("click",async()=>{
  remoteConfigUrl=remoteConfigInput.value.trim(); localStorage.setItem("beli_remote_config_url",remoteConfigUrl);
  try{await loadDeveloperConfig();alert("Developer config loaded.");}catch(e){alert("Config load failed: "+e.message);}
});
checkUpdateBtn?.addEventListener("click",checkRemoteUpdate);

studioToggleBtn?.addEventListener("dblclick",()=>radioContainer?.classList.toggle("hidden"));
saveSongBtn?.addEventListener("click",async()=>{
  const f=uploadSongFile.files?.[0]; if(!f)return alert("Pehle audio file select kijiye.");
  try{await saveOfflineSong(uploadSongTitle.value.trim()||f.name,f);uploadSongTitle.value="";uploadSongFile.value="";alert("Song offline library mein save ho gaya.");}catch(e){alert("Song save failed: "+e.message);}
});
playRadioBtn?.addEventListener("click",()=>playRadio(radioUrlInput.value.trim(),radioNameInput.value.trim()));
function readRadioForm(){
  return {channel:Math.max(1,Number(radioChannelInput?.value||0)||(radioStations.length+1)),url:radioUrlInput?.value.trim()||"",name:radioNameInput?.value.trim()||"Radio"};
}
function writeRadioForm(st){
  if(!st)return;
  if(radioChannelInput)radioChannelInput.value=st.channel||"";
  if(radioUrlInput)radioUrlInput.value=st.url||"";
  if(radioNameInput)radioNameInput.value=st.name||"";
}
saveRadioBtn?.addEventListener("click",()=>{
  const st=readRadioForm();
  if(!/^https?:\/\//i.test(st.url))return alert("Valid http/https stream URL dijiye.");
  const existing=radioStations.findIndex(x=>Number(x.channel)===Number(st.channel));
  if(existing>=0)radioStations[existing]=st;else radioStations.push(st);
  radioStations.sort((a,b)=>Number(a.channel||0)-Number(b.channel||0));
  localStorage.setItem("beli_radio_stations",JSON.stringify(radioStations));
  renderRadioStations();alert(`Channel ${st.channel} saved.`);
});
editRadioBtn?.addEventListener("click",()=>{
  const idx=Number(radioStationSelect?.value);
  if(!Number.isInteger(idx)||!radioStations[idx])return alert("Pehle station select kijiye.");
  const st=readRadioForm();
  if(!/^https?:\/\//i.test(st.url))return alert("Valid http/https stream URL dijiye.");
  radioStations[idx]=st;radioStations.sort((a,b)=>Number(a.channel||0)-Number(b.channel||0));
  localStorage.setItem("beli_radio_stations",JSON.stringify(radioStations));renderRadioStations();alert("Station updated.");
});
deleteRadioBtn?.addEventListener("click",()=>{
  const idx=Number(radioStationSelect?.value);
  if(!Number.isInteger(idx)||!radioStations[idx])return alert("Pehle station select kijiye.");
  radioStations.splice(idx,1);localStorage.setItem("beli_radio_stations",JSON.stringify(radioStations));
  renderRadioStations();alert("Station deleted.");
});
stopRadioBtn?.addEventListener("click",stopRadio);
radioStationSelect?.addEventListener("change",()=>{
  const st=radioStations[Number(radioStationSelect.value)];if(st)writeRadioForm(st);
});
document.getElementById("studioToggleBtn")?.addEventListener("contextmenu",e=>{e.preventDefault();radioContainer?.classList.toggle("hidden");});
renderRadioStations();
refreshOfflinePlaylist();
maybeDailyRandomMusic();
window.addEventListener("pointerdown", async () => {
  if (!voiceOn || speakingActive) return;
  // Do not silently consume microphone permission on arbitrary page taps.
  // The dedicated MIC button owns permission requests.
}, { once: true });

if(remoteConfigUrl) loadDeveloperConfig().catch(()=>{});

window.addEventListener("visibilitychange", ()=>{
  if(document.visibilityState==="visible" && !manualStopRequested && voiceOn && !speakingActive && !captureActive && !playbackListeningLock){
    setTimeout(()=>{ if(voiceOn && !speakingActive && !captureActive) startVoiceCapture(); },300);
  }
});
initSystem();
function resumeListeningAfterPlayback(){
  playbackListeningLock=false;
  voiceSegments=[];
  liveVoiceText="";
  if(canAutoListen() && !captureActive) setTimeout(()=>{ if(!manualStopRequested) startVoiceCapture(false); },350);
}


/* V26 hands-free bootstrap: browser permission still requires user gesture on many devices.
   Once permission has been granted, the assistant keeps the listening cycle alive automatically. */
window.addEventListener("load",()=>{
  // Hands-free is armed from startup. Browser permission may still require a
  // one-time user gesture on some Android Chrome versions; after permission is
  // granted this loop keeps the mic alive without repeated taps.
  let tries=0;
  const boot=()=>{
    if(!voiceOn || manualStopRequested || speakingActive || captureActive) return;
    tries++;
    try{ startVoiceCapture(false); }catch(e){}
    if(tries<8 && !captureActive){ setTimeout(boot, Math.min(1200, 250+tries*150)); }
  };
  setTimeout(boot,450);
});
document.addEventListener("visibilitychange",()=>{
  if(!document.hidden && voiceOn && !manualStopRequested && !captureActive && !speakingActive){
    setTimeout(()=>scheduleHandsFreeListen(250),350);
  }
});

/* ================================================================
   NATIVE ANDROID VOICE BRIDGE
   The original web app uses Web Speech APIs. Android WebView does not
   reliably expose SpeechRecognition, so the APK uses native Android
   SpeechRecognizer + TextToSpeech through this bridge.
   ================================================================ */
(function installNativeAndroidVoice(){
  if(!window.AndroidVoice || typeof window.AndroidVoice.isNativeVoiceAvailable !== "function") return;
  let available=false;
  try{ available=!!window.AndroidVoice.isNativeVoiceAvailable(); }catch(e){ available=false; }
  if(!available) return;

  window.__EV_NATIVE_VOICE__=true;
  let nativeSpeakingCallback=null;

  function clearNativeCaptureState(){
    captureActive=false;
    captureClosing=false;
    recognitionRunning=false;
    isListening=false;
    clearTimeout(captureTimer);
    clearInterval(countdownTimer);
    clearTimeout(restartTimer);
    clearVoiceEngineTimers();
    if(micBtn) micBtn.classList.remove("listening");
  }

  window.onNativeSpeechReady=function(){
    recognitionRunning=true;
    isListening=true;
    if(micBtn) micBtn.classList.add("listening");
    setStatus("🎤 Listening... boliye, main poori baat sun rahi hoon");
  };

  window.onNativeSpeechStarted=function(){
    recognitionRunning=true;
    isListening=true;
    if(micBtn) micBtn.classList.add("listening");
    setStatus("🎤 Sun rahi hoon...");
  };

  window.onNativeSpeechEnded=function(){
    recognitionRunning=false;
  };

  window.onNativeSpeechPartial=function(text){
    if(!captureActive) return;
    liveVoiceText=normalizeVoiceText(text);
    if(liveVoiceText) setStatus(`🎤 Suna: "${romanizeHindi(liveVoiceText)}"`);
  };

  window.onNativeSpeechError=function(message){
    recognitionRunning=false;
    if(!captureActive || manualStopRequested) return;
    setStatus("🎤 Mic ready hai — dobara boliye...");
  };

  window.onNativeSpeechFinal=function(text){
    const clean=normalizeVoiceText(text);
    clearNativeCaptureState();
    if(!clean || clean.length<MIN_VOICE_CHARS){
      setStatus("🎤 Awaaz clear nahi mili — dobara boliye...");
      if(canAutoListen()) setTimeout(()=>startVoiceCapture(false),500);
      return;
    }
    lastProcessedVoice=clean;
    liveVoiceText=clean;
    setStatus(`Suna: "${romanizeHindi(clean)}"`);
    processQueryEnhanced(clean,true);
  };

  window.onNativeSpeechDone=function(){
    speakingActive=false;
    if(!isAlexaMode && faceAvatar) faceAvatar.classList.remove("speaking");
    clearSpeechWatchdog();
    const cb=nativeSpeakingCallback;
    nativeSpeakingCallback=null;
    try{ if(cb) cb(); }catch(e){}
    if(!cb && canAutoListen()) setTimeout(()=>startVoiceCapture(false),350);
  };

  // Replace the browser SpeechRecognition path with Android's native recognizer.
  startVoiceCapture=function(fromUserGesture=false){
    if(fromUserGesture) manualStopRequested=false;
    if(manualStopRequested && !fromUserGesture) return;
    if(!voiceOn || speakingActive || captureActive) return;

    clearVoiceEngineTimers();
    clearTimeout(captureTimer);
    clearInterval(countdownTimer);
    clearTimeout(restartTimer);
    captureToken++;
    captureActive=true;
    captureClosing=false;
    voiceSegments=[];
    voiceAlternatives=[];
    liveVoiceText="";
    captureStartedAt=Date.now();
    setStatus("🎤 Mic ready — boliye...");
    if(micBtn) micBtn.classList.add("listening");

    try{
      AndroidVoice.startListening();
    }catch(e){
      clearNativeCaptureState();
      setStatus("🎤 Mic start nahi hua. Permission check kijiye.");
    }
  };

  stopVoiceCapture=function(userRequested=false,reason="user"){
    if(userRequested) manualStopRequested=true;
    clearNativeCaptureState();
    try{ AndroidVoice.stopListening(); }catch(e){}
    setStatus(userRequested ? "🔇 Mic stopped" : "🎤 Processing voice...");
  };

  // Replace Web Speech synthesis with Android TextToSpeech.
  speak=function(text,callback){
    if(!voiceOn){ if(callback) callback(); return; }
    const value=String(text||"").trim();
    if(!value){ if(callback) callback(); return; }
    nativeSpeakingCallback=callback||null;
    speakingActive=true;
    speechStartedAt=Date.now();
    clearSpeechWatchdog();
    clearTimeout(voiceAutoStartTimer);
    clearTimeout(handsFreeRetryTimer);
    captureActive=false;
    captureClosing=false;
    clearTimeout(captureTimer);
    clearInterval(countdownTimer);
    try{ AndroidVoice.stopListening(); }catch(e){}
    recognitionRunning=false;
    isListening=false;
    if(micBtn) micBtn.classList.remove("listening");
    if(!isAlexaMode && faceAvatar) faceAvatar.classList.add("speaking");
    setStatus("Speaking...");
    updateLiveDisplayMood?.("speaking");
    try{
      AndroidVoice.speak(value);
    }catch(e){
      speakingActive=false;
      nativeSpeakingCallback=null;
      if(!isAlexaMode && faceAvatar) faceAvatar.classList.remove("speaking");
      try{if(callback)callback();}catch(err){}
    }
  };

  // The existing mute button controls the Web Speech engine. Add native stop/start
  // as well so the same UI works in the APK.
  document.getElementById("voiceToggleBtn")?.addEventListener("click",()=>{
    if(!voiceOn){
      try{AndroidVoice.stopListening();}catch(e){}
      try{AndroidVoice.stopSpeaking();}catch(e){}
      clearNativeCaptureState();
      speakingActive=false;
    }else if(!speakingActive && !captureActive){
      manualStopRequested=false;
      setTimeout(()=>startVoiceCapture(true),100);
    }
  });

  setStatus("📱 Android voice engine ready — mic dabakar boliye");
})();
